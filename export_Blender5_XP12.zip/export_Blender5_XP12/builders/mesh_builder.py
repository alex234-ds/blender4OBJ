# =============================================================================
# Project : export_Blender5_XP12
# File    : builders/mesh_builder.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Build OBJ8 triangle geometry tables.
#
# Назначение (RU):
#     Формирование таблиц геометрии треугольников OBJ8.
#
# OBJ8:
#     Triangle front face uses clockwise vertex order.
#     Blender uses the opposite winding convention for its visible
#     front-facing polygon surface, therefore the triangle loop order
#     is reversed during export.
# =============================================================================


class ALX_MeshBuilder:

    def build(
        self,
        mesh_data,
    ):

        obj = mesh_data["object"]
        mesh = mesh_data["mesh"]
        uv_layer = mesh_data["uv_layer"]

        #
        # IMPORTANT:
        #
        # mesh_collector.py has already obtained the object's real Blender
        # world matrix while the Armature was in REST pose.
        #
        # This is especially important for objects parented to a bone.
        # Reconstructing the transform here from bone.matrix_local,
        # matrix_parent_inverse and matrix_basis can introduce the bone roll
        # into the exported VT coordinates and produce the unwanted initial
        # rotation in X-Plane.
        #
        # For ordinary objects this is simply their normal matrix_world.
        #

        world = mesh_data.get(
            "export_world_matrix"
        )

        if world is None:

            world = obj.matrix_world.copy()

        #
        # Normal transformation.
        #

        normal_matrix = (
            world.to_3x3()
            .inverted()
            .transposed()
        )

        vt_table = []
        idx_table = []
        tris_table = []

        #
        # Blender loop triangles already contain the triangulated
        # representation of the evaluated mesh.
        #
        # OBJ8 requires clockwise vertex order for the front face.
        #

        for triangle in mesh.loop_triangles:

            start_index = len(
                idx_table
            )

            loop_indices = list(
                triangle.loops
            )

            loop_indices.reverse()

            for loop_index in loop_indices:

                loop = mesh.loops[
                    loop_index
                ]

                vertex = mesh.vertices[
                    loop.vertex_index
                ]

                #
                # World-space position.
                #

                co = world @ vertex.co

                #
                # World-space normal.
                #

                normal = (
                    normal_matrix
                    @ loop.normal
                ).normalized()

                #
                # UV coordinates.
                #

                u = 0.0
                v = 0.0

                if uv_layer is not None:

                    uv = uv_layer[
                        loop_index
                    ].uv

                    u = uv.x
                    v = uv.y

                #
                # Blender -> X-Plane coordinate system.
                #
                # Blender:
                #     X = right
                #     Y = forward
                #     Z = up
                #
                # X-Plane OBJ8:
                #     X = right
                #     Y = up
                #     Z = south
                #

                vt_table.append({

                    "x": co.x,
                    "y": co.z,
                    "z": -co.y,

                    "nx": normal.x,
                    "ny": normal.z,
                    "nz": -normal.y,

                    "u": u,
                    "v": v,

                })

                idx_table.append(
                    len(vt_table) - 1
                )

            tris_table.append({

                "offset": start_index,

                "count": 3,

            })

        return {

            "vt_table": vt_table,

            "idx_table": idx_table,

            "tris_table": tris_table,

        }
