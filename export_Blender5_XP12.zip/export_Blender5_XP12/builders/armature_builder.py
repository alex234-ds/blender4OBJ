# =============================================================================
# Project : export_Blender5_XP12
# File    : builders/armature_builder.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Extract armature and bone hierarchy information.
#
# Назначение (RU):
#     Получение структуры арматуры и иерархии костей.
# =============================================================================


class ALX_ArmatureBuilder:

    """
    Builds export data for a Blender armature.
    """

    def build(
        self,
        obj,
    ):

        armature = obj.data

        bones = []

        for bone in armature.bones:

            parent_name = None

            if bone.parent is not None:

                parent_name = (
                    bone.parent.name
                )

            bones.append({

                "name": bone.name,

                "parent": parent_name,

                "head": (
                    bone.head_local.x,
                    bone.head_local.y,
                    bone.head_local.z,
                ),

                "tail": (
                    bone.tail_local.x,
                    bone.tail_local.y,
                    bone.tail_local.z,
                ),

                "length": bone.length,

                "matrix_local": (
                    bone.matrix_local.copy()
                ),

            })

        return {

            "object": obj,

            "armature": armature,

            "bones": bones,

        }
