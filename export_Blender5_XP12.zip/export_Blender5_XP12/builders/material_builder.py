# =============================================================================
# Project : export_Blender5_XP12
# File    : builders/material_builder.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
# Extract OBJ8 texture information from Blender materials.
#
# Назначение (RU):
# Получение информации о текстурах OBJ8 из материалов Blender.
# =============================================================================

import bpy


class ALX_MaterialBuilder:

    def build(
        self,
        obj,
        scene,
    ):

        #
        # Scan all material slots.
        #

        for slot in obj.material_slots:

            material = slot.material

            if material is None:
                continue

            if material not in scene.materials:

                scene.materials.append(
                    material
                )

            if not material.use_nodes:
                continue

            node_tree = material.node_tree

            if node_tree is None:
                continue

            principled = (
                self._find_principled(
                    node_tree
                )
            )

            if principled is None:
                continue

            #
            # Base texture.
            #

            base_color = (
                principled.inputs.get(
                    "Base Color"
                )
            )

            image = (
                self._find_image_from_socket(
                    base_color
                )
            )

            if image is not None:

                filename = (
                    self._image_filename(
                        image
                    )
                )

                if filename:

                    if scene.texture is None:

                        scene.texture = filename

            #
            # Normal texture.
            #

            normal_socket = (
                principled.inputs.get(
                    "Normal"
                )
            )

            image = (
                self._find_image_from_socket(
                    normal_socket
                )
            )

            if image is not None:

                filename = (
                    self._image_filename(
                        image
                    )
                )

                if filename:

                    if scene.texture_normal is None:

                        scene.texture_normal = (
                            filename
                        )

            #
            # Emissive texture.
            #

            emission_socket = (
                principled.inputs.get(
                    "Emission Color"
                )
            )

            if emission_socket is None:

                emission_socket = (
                    principled.inputs.get(
                        "Emission"
                    )
                )

            image = (
                self._find_image_from_socket(
                    emission_socket
                )
            )

            if image is not None:

                filename = (
                    self._image_filename(
                        image
                    )
                )

                if filename:

                    if scene.texture_lit is None:

                        scene.texture_lit = (
                            filename
                        )

    # =========================================================================
    # PRINCIPLED BSDF
    # =========================================================================

    def _find_principled(
        self,
        node_tree,
    ):

        for node in node_tree.nodes:

            if node.type == "BSDF_PRINCIPLED":

                return node

        return None

    # =========================================================================
    # FIND IMAGE FROM SOCKET
    # =========================================================================

    def _find_image_from_socket(
        self,
        socket,
    ):

        if socket is None:
            return None

        if not socket.is_linked:
            return None

        visited = set()

        for link in socket.links:

            image = (
                self._find_image_from_node(
                    link.from_node,
                    visited,
                )
            )

            if image is not None:

                return image

        return None

    # =========================================================================
    # FIND IMAGE FROM NODE
    # =========================================================================

    def _find_image_from_node(
        self,
        node,
        visited,
    ):

        node_key = node.as_pointer()

        if node_key in visited:
            return None

        visited.add(
            node_key
        )

        #
        # Direct image texture.
        #

        if (
            node.type == "TEX_IMAGE"
            and node.image is not None
        ):

            return node.image

        #
        # Search connected inputs.
        #

        for socket in node.inputs:

            if not socket.is_linked:
                continue

            for link in socket.links:

                image = (
                    self._find_image_from_node(
                        link.from_node,
                        visited,
                    )
                )

                if image is not None:

                    return image

        #
        # Search inside node groups.
        #

        if node.type == "GROUP":

            group_tree = node.node_tree

            if group_tree is not None:

                for group_node in group_tree.nodes:

                    image = (
                        self._find_image_from_node(
                            group_node,
                            visited,
                        )
                    )

                    if image is not None:

                        return image

        return None

    # =========================================================================
    # IMAGE FILENAME
    # =========================================================================

    def _image_filename(
        self,
        image,
    ):

        if image is None:
            return None

        #
        # Blender filepath.
        #

        filepath = image.filepath

        if filepath:

            filename = bpy.path.basename(
                filepath
            )

            if filename:

                return filename

        #
        # Fallback for packed/generated images.
        #

        if image.name:

            filename = bpy.path.basename(
                image.name
            )

            if filename:

                return filename

        return None
