# =============================================================================
# Project : export_Blender5_XP12
# File    : ui/material_xplane.py
#
# Purpose:
#     X-Plane 12 material settings for Blender materials.
# =============================================================================

import bpy
from bpy.types import Panel


class ALX_PT_XPlaneMaterial(Panel):

    bl_idname = "ALX_PT_XPlaneMaterial"
    bl_label = "X-Plane Material"
    bl_description = "X-Plane 12 material settings"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return (
            obj is not None
            and obj.type == "MESH"
            and getattr(obj, "active_material", None) is not None
        )

    def draw(self, context):
        layout = self.layout
        material = context.object.active_material
        settings = getattr(material, "alx_xplane_material", None)

        if settings is None:
            layout.label(text="X-Plane material properties unavailable", icon="ERROR")
            return

        box = layout.box()
        box.label(text="X-Plane 12")
        box.prop(settings, "glass", text="Glass")

        if settings.glass:
            box.label(
                text="OBJ: BLEND_GLASS",
                icon="CHECKMARK",
            )
            box.label(
                text="Attach this OBJ as Glass in Plane Maker.",
                icon="INFO",
            )


classes = (
    ALX_PT_XPlaneMaterial,
)
