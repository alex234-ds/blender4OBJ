# =============================================================================
#
# Project : export_Blender5_XP12
# File    : ui/bone_xplane.py
#
# Company : Alex234 Design Studio
#
# Purpose (EN):
#     X-Plane settings panel for individual Blender bones.
#
# Назначение (RU):
#     Панель X-Plane с индивидуальными настройками каждой кости.
#
# Blender : 5.1+
#
# IMPORTANT:
#     This file is the ONLY place where the Bone X-Plane panel and its
#     operators are registered.
# =============================================================================

import math

import bpy

from bpy.types import Operator, Panel
from bpy_extras import anim_utils

from ..collectors.armature_collector import ALX_ArmatureCollector


# =============================================================================
# HELPERS
# =============================================================================

def _get_active_bone(context):

    bone = getattr(
        context,
        "bone",
        None,
    )

    if bone is not None:
        return bone

    bone = getattr(
        context,
        "active_bone",
        None,
    )

    if bone is not None:
        return bone

    obj = getattr(
        context,
        "object",
        None,
    )

    if obj is not None and obj.type == "ARMATURE":

        active = getattr(
            obj.data.bones,
            "active",
            None,
        )

        if active is not None:
            return active

    return None


def _get_settings(context):

    bone = _get_active_bone(
        context
    )

    if bone is None:
        return None

    return getattr(
        bone,
        "alx_xplane",
        None,
    )


def _has_dataref(settings):

    if settings is None:
        return False

    return bool(
        str(
            settings.dataref_name
        ).strip()
    )


# =============================================================================
# AUTO
# =============================================================================

class ALX_OT_BoneXPlaneAuto(Operator):

    bl_idname = "alx_bone_xplane.auto"
    bl_label = "Auto"
    bl_description = (
        "Copy existing Blender bone animation "
        "into the X-Plane table"
    )

    @classmethod
    def poll(cls, context):

        settings = _get_settings(
            context
        )

        if settings is None:
            return False

        if not settings.animation_enabled:
            return False

        if not _has_dataref(settings):
            return False

        return (
            len(
                settings.keyframes
            ) == 0
        )

    def execute(self, context):

        settings = _get_settings(
            context
        )

        bone = _get_active_bone(
            context
        )

        obj = getattr(
            context,
            "object",
            None,
        )

        if (
            settings is None
            or bone is None
            or obj is None
        ):
            return {"CANCELLED"}

        if not _has_dataref(settings):

            self.report(
                {"WARNING"},
                "Dataref Name is empty",
            )

            return {"CANCELLED"}

        collector = (
            ALX_ArmatureCollector()
        )

        collected = collector.collect(
            obj,
            respect_xplane=False,
        )

        source_bone = None

        for item in collected.get(
            "bones",
            [],
        ):

            if item.get(
                "name"
            ) == bone.name:

                source_bone = item
                break

        if source_bone is None:

            self.report(
                {"WARNING"},
                f"Bone '{bone.name}' was not found",
            )

            return {"CANCELLED"}

        source_animation = (
            source_bone.get(
                "animation",
                [],
            )
        )

        if not source_animation:

            self.report(
                {"WARNING"},
                "No Blender animation keys found for this bone",
            )

            return {"CANCELLED"}

        #
        # Auto must copy the actual Blender Y rotation key values.
        #
        # For Euler animation Blender stores rotation_euler values
        # in radians. The X-Plane table uses degrees.
        #
        # Do NOT use source_bone["animation"]["angle"] here:
        # that value is the calculated twist around the bone axis
        # and can differ from the actual Blender rotation_euler Y
        # value shown in the Dope Sheet / bone transform.
        #
        y_fcurve = None

        animation_data = getattr(
            obj,
            "animation_data",
            None,
        )

        if animation_data is not None:

            action = getattr(
                animation_data,
                "action",
                None,
            )

            if action is not None:

                action_slot = getattr(
                    animation_data,
                    "action_slot",
                    None,
                )

                channelbags = []

                if action_slot is not None:

                    channelbag = (
                        anim_utils.action_get_channelbag_for_slot(
                            action,
                            action_slot,
                        )
                    )

                    if channelbag is not None:
                        channelbags.append(
                            channelbag
                        )

                if not channelbags:

                    for layer in action.layers:

                        for strip in layer.strips:

                            for channelbag in strip.channelbags:

                                if (
                                    action_slot is not None
                                    and channelbag.slot != action_slot
                                ):
                                    continue

                                channelbags.append(
                                    channelbag
                                )

                target_path = (
                    f'pose.bones["{bone.name}"].rotation_euler'
                )

                for channelbag in channelbags:

                    for fcurve in channelbag.fcurves:

                        if (
                            fcurve.data_path == target_path
                            and fcurve.array_index == 1
                        ):

                            y_fcurve = fcurve
                            break

                    if y_fcurve is not None:
                        break

        settings.keyframes.clear()

        for key in source_animation:

            item = (
                settings.keyframes.add()
            )

            frame = float(
                key.get(
                    "frame",
                    1.0,
                )
            )

            item.frame = frame

            #
            # Auto initially uses the actual Blender bone angle for BOTH
            # X-Plane values. The user may then edit DatarefValue and
            # BoneAngle independently.
            #
            if y_fcurve is not None:

                value_radians = None

                for keyframe in y_fcurve.keyframe_points:

                    if abs(
                        float(keyframe.co.x) - frame
                    ) <= 1.0e-8:

                        value_radians = float(
                            keyframe.co.y
                        )
                        break

                if value_radians is not None:

                    angle = math.degrees(
                        value_radians
                    )

                else:

                    angle = float(
                        key.get(
                            "angle",
                            0.0,
                        )
                    )

            else:

                angle = float(
                    key.get(
                        "angle",
                        0.0,
                    )
                )

            item.dataref_value = angle
            item.bone_angle = angle

        # Do not modify active_keyframe here.

        self.report(
            {"INFO"},
            (
                f"Imported "
                f"{len(settings.keyframes)} "
                f"keyframe(s)"
            ),
        )

        return {"FINISHED"}


# =============================================================================
# ADD KEY
# =============================================================================

class ALX_OT_BoneXPlaneAddKey(Operator):

    bl_idname = "alx_bone_xplane.add_key"
    bl_label = "+"
    bl_description = (
        "Add an X-Plane animation key"
    )

    @classmethod
    def poll(cls, context):

        settings = _get_settings(
            context
        )

        return (
            settings is not None
            and settings.animation_enabled
            and _has_dataref(settings)
        )

    def execute(self, context):

        settings = _get_settings(
            context
        )

        if settings is None:
            return {"CANCELLED"}

        item = (
            settings.keyframes.add()
        )

        if len(
            settings.keyframes
        ) > 1:

            previous = (
                settings.keyframes[
                    len(settings.keyframes) - 2
                ]
            )

            item.frame = (
                previous.frame + 1.0
            )

            item.dataref_value = (
                previous.dataref_value
            )

            item.bone_angle = (
                previous.bone_angle
            )

        else:

            item.frame = 1.0
            item.dataref_value = 0.0
            item.bone_angle = 0.0

        settings.active_keyframe = (
            len(
                settings.keyframes
            ) - 1
        )

        return {"FINISHED"}


# =============================================================================
# REMOVE KEY
# =============================================================================

class ALX_OT_BoneXPlaneRemoveKey(Operator):

    bl_idname = "alx_bone_xplane.remove_key"
    bl_label = "-"
    bl_description = (
        "Remove the selected X-Plane animation key"
    )

    @classmethod
    def poll(cls, context):

        settings = _get_settings(
            context
        )

        return (
            settings is not None
            and settings.animation_enabled
            and _has_dataref(settings)
            and len(settings.keyframes) > 0
        )

    def execute(self, context):

        settings = _get_settings(
            context
        )

        if (
            settings is None
            or len(settings.keyframes) == 0
        ):
            return {"CANCELLED"}

        index = int(
            settings.active_keyframe
        )

        if (
            index < 0
            or index >= len(settings.keyframes)
        ):

            index = (
                len(settings.keyframes) - 1
            )

        settings.keyframes.remove(
            index
        )

        if len(
            settings.keyframes
        ) == 0:

            settings.active_keyframe = -1

        else:

            settings.active_keyframe = min(
                index,
                len(settings.keyframes) - 1,
            )

        return {"FINISHED"}


# =============================================================================
# CLEAR
# =============================================================================

class ALX_OT_BoneXPlaneClear(Operator):

    bl_idname = "alx_bone_xplane.clear"
    bl_label = "Clear"
    bl_description = (
        "Clear all X-Plane animation keys"
    )

    @classmethod
    def poll(cls, context):

        settings = _get_settings(
            context
        )

        return (
            settings is not None
            and settings.animation_enabled
            and _has_dataref(settings)
            and len(settings.keyframes) > 0
        )

    def execute(self, context):

        settings = _get_settings(
            context
        )

        if settings is None:
            return {"CANCELLED"}

        settings.keyframes.clear()

        settings.active_keyframe = -1

        return {"FINISHED"}


# =============================================================================
# PANEL
# =============================================================================

class ALX_PT_BoneXPlane(bpy.types.Panel):

    bl_idname = "ALX_PT_BoneXPlane"
    bl_label = "X-Plane12"
    bl_description = (
        "X-Plane animation settings for this bone"
    )

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "bone"

    bl_options = {
        "DEFAULT_CLOSED",
    }

    @classmethod
    def poll(cls, context):

        obj = getattr(
            context,
            "object",
            None,
        )

        bone = _get_active_bone(
            context
        )

        if obj is None:
            return False

        if obj.type != "ARMATURE":
            return False

        if bone is None:
            return False

        return True

    def draw(self, context):

        layout = self.layout

        settings = _get_settings(
            context
        )

        if settings is None:

            layout.label(
                text="X-Plane properties unavailable",
                icon="ERROR",
            )

            return

        row = layout.row(
            align=True
        )

        row.prop(
            settings,
            "animation_enabled",
            text="Анимация",
        )

        auto = row.row(
            align=True
        )

        auto.enabled = (
            settings.animation_enabled
            and _has_dataref(settings)
            and len(settings.keyframes) == 0
        )

        auto.operator(
            ALX_OT_BoneXPlaneAuto.bl_idname,
            text="Auto",
        )

        if not settings.animation_enabled:
            return

        layout.separator()

        layout.prop(
            settings,
            "dataref_name",
            text="Dataref Name",
        )

        if not _has_dataref(settings):

            layout.label(
                text="Dataref Name is required",
                icon="ERROR",
            )

            return

        layout.separator()

        box = layout.box()

        header = box.row(
            align=True
        )

        header.label(
            text="№ keyframe"
        )

        header.label(
            text="DatarefValue"
        )

        header.label(
            text="BoneAngle"
        )

        header.label(
            text=""
        )

        for index, key in enumerate(
            settings.keyframes
        ):

            row = box.row(
                align=True
            )

            row.prop(
                key,
                "frame",
                text="",
            )

            row.prop(
                key,
                "dataref_value",
                text="",
            )

            row.prop(
                key,
                "bone_angle",
                text="",
            )

            row.operator(
                ALX_OT_BoneXPlaneRemoveKey.bl_idname,
                text="-",
            )

        row = box.row(
            align=True
        )

        row.operator(
            ALX_OT_BoneXPlaneAddKey.bl_idname,
            text="+",
        )

        row.operator(
            ALX_OT_BoneXPlaneRemoveKey.bl_idname,
            text="-",
        )

        row = layout.row()

        row.enabled = (
            len(
                settings.keyframes
            ) > 0
        )

        row.operator(
            ALX_OT_BoneXPlaneClear.bl_idname,
            text="Clear",
        )


# =============================================================================
# CLASSES
# =============================================================================

classes = (
    ALX_OT_BoneXPlaneAuto,
    ALX_OT_BoneXPlaneAddKey,
    ALX_OT_BoneXPlaneRemoveKey,
    ALX_OT_BoneXPlaneClear,
    ALX_PT_BoneXPlane,
)
