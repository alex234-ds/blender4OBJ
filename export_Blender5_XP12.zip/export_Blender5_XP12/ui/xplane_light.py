# =============================================================================
# Project : export_Blender5_XP12
# File    : ui/xplane_light.py
#
# Purpose:
#     X-Plane 12 light settings for Blender Light objects.
# =============================================================================

import bpy
import textwrap
from bpy.types import Operator, Panel


from ..core.xplane_lights import PARAM_DEFS



class ALX_OT_XPlaneLightInfo(Operator):
    bl_idname = "alx_xplane_light.info"
    bl_label = "X-Plane Light"
    bl_description = "Show information about the selected X-Plane light type"

    message: bpy.props.StringProperty(default="")

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=520)

    def draw(self, context):
        column = self.layout.column(align=True)
        for paragraph in self.message.split("\n"):
            if not paragraph.strip():
                column.separator()
                continue
            for line in textwrap.wrap(paragraph, width=72):
                column.label(text=line)


class ALX_PT_XPlaneLight(Panel):
    bl_idname = "ALX_PT_XPlaneLight"
    bl_label = "X-Plane Light"
    bl_description = "X-Plane 12 OBJ light settings"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"

    TYPE_INFO = {
        "NONE": "Light is not exported to OBJ.",
        "NAMED": "LIGHT_NAMED: uses an X-Plane predefined named light. Position comes from the Blender Light object.",
        "PARAM": "LIGHT_PARAM: uses a predefined X-Plane light and adds type-specific numeric parameters.",
        "CUSTOM": "LIGHT_CUSTOM: billboard light using the OBJ texture. RGBA, size and UV rectangle are written directly; an optional 9-float DataRef may modify them.",
        "SPILL_CUSTOM": "LIGHT_SPILL_CUSTOM: real spill illumination with custom color, radius, direction and cone. Position and direction are exported from the Blender Light object.",
    }

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return obj is not None and obj.type == "LIGHT"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        settings = obj.alx_xplane_light

        row = layout.row(align=True)
        row.prop(settings, "enabled", text="Light")

        if not settings.enabled:
            return

        row = layout.row(align=True)
        row.prop(settings, "type", text="Type")
        info = row.operator(ALX_OT_XPlaneLightInfo.bl_idname, text="ⓘ")
        info.message = self.TYPE_INFO.get(settings.type, "")

        if settings.type == "NONE":
            return

        layout.label(text=f"Object position: {obj.location.x:.6f}, {obj.location.y:.6f}, {obj.location.z:.6f}")

        if settings.type == "NAMED":
            layout.prop(settings, "light_name", text="Light Name")

        elif settings.type == "PARAM":
            layout.prop(settings, "parameterized_type", text="Light")
            params = PARAM_DEFS.get(settings.parameterized_type, [])
            box = layout.box()
            box.label(text="Parameters")
            for index, (label, default) in enumerate(params, 1):
                box.prop(settings, f"param{index}", text=label)
            if settings.parameterized_type == "airplane_strobe_omni":
                box.label(text="I1/I2/I3 are ignored by X-Plane; keep them at 0.", icon="INFO")
            box.label(text="All values follow the X-Plane 12 Aircraft Parameterized Light Guide.", icon="LIGHT")

        elif settings.type == "CUSTOM":
            box = layout.box()
            box.label(text="Color / Brightness")
            box.prop(settings, "red", text="R")
            box.prop(settings, "green", text="G")
            box.prop(settings, "blue", text="B")
            box.prop(settings, "alpha", text="A")

            box = layout.box()
            box.label(text="Billboard")
            box.prop(settings, "size", text="Size")
            box.prop(settings, "s1", text="S1")
            box.prop(settings, "t1", text="T1")
            box.prop(settings, "s2", text="S2")
            box.prop(settings, "t2", text="T2")
            layout.prop(settings, "dataref", text="Dataref")

            if not getattr(context.scene, "alx_export_settings", None):
                pass

        elif settings.type == "SPILL_CUSTOM":
            box = layout.box()
            box.label(text="Color / Brightness")
            box.prop(settings, "red", text="R")
            box.prop(settings, "green", text="G")
            box.prop(settings, "blue", text="B")
            box.prop(settings, "alpha", text="A")
            box.prop(settings, "size", text="Size (m)")

            box = layout.box()
            box.label(text="Direction")
            box.prop(settings, "direction_x", text="X")
            box.prop(settings, "direction_y", text="Y")
            box.prop(settings, "direction_z", text="Z")
            box.prop(settings, "semi", text="Semi")
            layout.prop(settings, "dataref", text="Dataref")

        layout.separator()
        layout.label(text="Coordinates are exported as OBJ/X-Plane: X=X, Y=Z, Z=-Y.")


classes = (
    ALX_OT_XPlaneLightInfo,
    ALX_PT_XPlaneLight,
)
