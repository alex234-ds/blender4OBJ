# =============================================================================
# Project : export_Blender5_XP12
# File    : ui/object_xplane.py
#
# Purpose:
#     X-Plane OBJ manipulator settings for individual mesh objects.
# =============================================================================

import bpy
import textwrap
from bpy.types import Operator, Panel


def _get_bone_binding(obj):
    """Return (armature_object, bone) when the mesh is directly parented to a bone."""
    if obj is None or obj.type != "MESH":
        return None, None

    parent = getattr(obj, "parent", None)

    if parent is None or parent.type != "ARMATURE":
        return None, None

    if getattr(obj, "parent_type", "") not in {"BONE", "BONE_RELATIVE"}:
        return None, None

    bone_name = getattr(obj, "parent_bone", "")
    if not bone_name:
        return None, None

    bone = parent.data.bones.get(bone_name)
    if bone is None:
        return None, None

    return parent, bone


def _bone_axis_xplane(obj):
    """Return the bound bone head and axis in the same world/OBJ space as VT."""
    armature, bone = _get_bone_binding(obj)

    if armature is None or bone is None:
        return None

    head_world = armature.matrix_world @ bone.head_local

    axis_local = bone.tail_local - bone.head_local
    if axis_local.length <= 1.0e-12:
        return None

    axis_local.normalize()

    axis_world = armature.matrix_world.to_3x3() @ axis_local
    if axis_world.length <= 1.0e-12:
        return None

    axis_world.normalize()

    # Blender world -> X-Plane OBJ coordinates:
    # X = X, Y = Z, Z = -Y.
    return (
        (float(head_world.x), float(head_world.z), float(-head_world.y)),
        (float(axis_world.x), float(axis_world.z), float(-axis_world.y)),
    )


class ALX_OT_ObjectXPlaneManipulatorInfo(Operator):
    bl_idname = "alx_object_xplane.manip_info"
    bl_label = "Информация"
    bl_description = "Показать описание выбранного манипулятора"

    message: bpy.props.StringProperty(default="")

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=520)

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)
        for paragraph in self.message.split("\n"):
            if not paragraph.strip():
                column.separator()
                continue
            for line in textwrap.wrap(paragraph, width=72):
                column.label(text=line)


class ALX_OT_ObjectXPlaneManipulatorReset(Operator):
    bl_idname = "alx_object_xplane.manip_reset"
    bl_label = "Reset"
    bl_description = "Disable the X-Plane manipulator for this object"

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return obj is not None and obj.type == "MESH" and hasattr(obj, "alx_xplane_manip")

    def execute(self, context):
        settings = context.object.alx_xplane_manip
        settings.enabled = False
        settings.type = "NONE"
        return {"FINISHED"}


class ALX_OT_ObjectXPlaneManipulatorUseBoneAxis(Operator):
    bl_idname = "alx_object_xplane.use_bone_axis"
    bl_label = "Use Bone Axis"
    bl_description = (
        "Copy the directly parented bone head and axis into the manipulator. "
        "Coordinates are converted to the OBJ/X-Plane coordinate system."
    )

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        if obj is None or obj.type != "MESH":
            return False

        settings = getattr(obj, "alx_xplane_manip", None)
        if settings is None:
            return False

        if settings.type not in {"DRAG_AXIS", "COMMAND_AXIS", "DRAG_ROTATE"}:
            return False

        return _bone_axis_xplane(obj) is not None

    def execute(self, context):
        obj = getattr(context, "object", None)
        settings = getattr(obj, "alx_xplane_manip", None)

        result = _bone_axis_xplane(obj) if obj is not None else None

        if settings is None or result is None:
            self.report(
                {"WARNING"},
                "Object is not directly parented to a valid bone",
            )
            return {"CANCELLED"}

        origin, axis = result

        settings.axis_x = axis[0]
        settings.axis_y = axis[1]
        settings.axis_z = axis[2]

        if settings.type == "DRAG_ROTATE":
            settings.origin_x = origin[0]
            settings.origin_y = origin[1]
            settings.origin_z = origin[2]

        self.report(
            {"INFO"},
            f"Bone axis copied from '{obj.parent_bone}'",
        )

        return {"FINISHED"}


class ALX_PT_ObjectXPlaneManipulator(Panel):
    bl_idname = "ALX_PT_ObjectXPlaneManipulator"
    bl_label = "X-Plane Manipulator"
    bl_description = "X-Plane OBJ manipulator for this mesh object"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}

    TYPE_INFO = {
        "NONE": "Манипулятор отключён.",
        "DRAG_AXIS": "Перетаскивание вдоль 3D-оси меняет значение Dataref.",
        "DRAG_XY": "Перетаскивание по экранным X/Y направлениям меняет два Dataref.",
        "COMMAND": "Команда выполняется, пока мышь удерживается на меше.",
        "COMMAND_AXIS": "Перетаскивание вдоль оси вызывает одну команду в положительном направлении и другую в отрицательном.",
        "PUSH": "Кнопка: при нажатии Dataref получает Down Value, при отпускании — Up Value.",
        "RADIO": "Нажатие устанавливает Dataref в указанное Value.",
        "TOGGLE": "Нажатие переключает Dataref между On Value и Off Value.",
        "DRAG_ROTATE": "Вращательный манипулятор. Dataref1 преобразуется в угол между Angle 1 и Angle 2 вокруг указанного Origin/Axis.",
        "COMMAND_KNOB": "VR-ориентированная ручка с двумя командами.",
        "COMMAND_SWITCH_UP_DOWN": "VR-ориентированный переключатель вверх/вниз с двумя командами.",
        "COMMAND_SWITCH_LEFT_RIGHT": "VR-ориентированный переключатель влево/вправо с двумя командами.",
        "AXIS_KNOB": "Dataref-driven ручка: клик/удержание изменяют Dataref на заданную величину.",
        "AXIS_SWITCH_UP_DOWN": "Dataref-driven переключатель вверх/вниз.",
        "AXIS_SWITCH_LEFT_RIGHT": "Dataref-driven переключатель влево/вправо.",
    }

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return obj is not None and obj.type == "MESH"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        settings = context.object.alx_xplane_manip

        row = layout.row(align=True)
        row.prop(settings, "enabled", text="Манипулятор")
        row.operator(ALX_OT_ObjectXPlaneManipulatorReset.bl_idname, text="Reset")

        if not settings.enabled:
            return

        row = layout.row(align=True)
        row.prop(settings, "type", text="Type")
        info = row.operator(
            ALX_OT_ObjectXPlaneManipulatorInfo.bl_idname,
            text="ⓘ",
        )
        info.message = self.TYPE_INFO.get(settings.type, "")

        if settings.type == "NONE":
            return

        layout.prop(settings, "cursor", text="Cursor")

        if settings.type == "DRAG_AXIS":
            self._axis(layout, settings, obj)
            self._range(layout, settings)
            self._dataref(layout, settings, "dataref1")

        elif settings.type == "DRAG_XY":
            layout.prop(settings, "dx", text="DX")
            layout.prop(settings, "dy", text="DY")
            layout.prop(settings, "v1min", text="Dataref 1 Min")
            layout.prop(settings, "v1max", text="Dataref 1 Max")
            layout.prop(settings, "v2min", text="Dataref 2 Min")
            layout.prop(settings, "v2max", text="Dataref 2 Max")
            self._dataref(layout, settings, "dataref1")
            self._dataref(layout, settings, "dataref2")

        elif settings.type == "COMMAND":
            layout.prop(settings, "command1", text="Command")

        elif settings.type == "COMMAND_AXIS":
            self._axis(layout, settings, obj)
            layout.prop(settings, "command1", text="Positive Command")
            layout.prop(settings, "command2", text="Negative Command")

        elif settings.type == "PUSH":
            layout.prop(settings, "v1", text="Down Value")
            layout.prop(settings, "v2", text="Up Value")
            self._dataref(layout, settings, "dataref1")

        elif settings.type == "RADIO":
            layout.prop(settings, "v1", text="Value")
            self._dataref(layout, settings, "dataref1")

        elif settings.type == "TOGGLE":
            layout.prop(settings, "v1", text="On Value")
            layout.prop(settings, "v2", text="Off Value")
            self._dataref(layout, settings, "dataref1")

        elif settings.type == "DRAG_ROTATE":
            box = layout.box()
            box.label(text="Rotation Origin")
            box.prop(settings, "origin_x", text="X")
            box.prop(settings, "origin_y", text="Y")
            box.prop(settings, "origin_z", text="Z")

            box = layout.box()
            box.label(text="Rotation Axis")
            box.prop(settings, "axis_x", text="X")
            box.prop(settings, "axis_y", text="Y")
            box.prop(settings, "axis_z", text="Z")

            if _get_bone_binding(obj)[0] is not None:
                box.operator(
                    ALX_OT_ObjectXPlaneManipulatorUseBoneAxis.bl_idname,
                    text="Use Bone Axis",
                    icon="BONE_DATA",
                )

            box = layout.box()
            box.label(text="Rotation")
            box.prop(settings, "angle1", text="Angle 1")
            box.prop(settings, "angle2", text="Angle 2")
            box.prop(settings, "lift", text="Lift")
            box.prop(settings, "v1min", text="Dataref 1 Min")
            box.prop(settings, "v1max", text="Dataref 1 Max")
            self._dataref(layout, settings, "dataref1")
            box.prop(settings, "v2min", text="Dataref 2 Min")
            box.prop(settings, "v2max", text="Dataref 2 Max")
            self._dataref(box, settings, "dataref2")

        elif settings.type in {"COMMAND_KNOB", "COMMAND_SWITCH_UP_DOWN", "COMMAND_SWITCH_LEFT_RIGHT"}:
            layout.prop(settings, "command1", text="Positive Command")
            layout.prop(settings, "command2", text="Negative Command")

        elif settings.type in {"AXIS_KNOB", "AXIS_SWITCH_UP_DOWN", "AXIS_SWITCH_LEFT_RIGHT"}:
            layout.prop(settings, "v1min", text="Min")
            layout.prop(settings, "v1max", text="Max")
            layout.prop(settings, "click_delta", text="Click Delta")
            layout.prop(settings, "hold_delta", text="Hold Delta")
            self._dataref(layout, settings, "dataref1")

        layout.separator()
        layout.prop(settings, "tooltip", text="Tooltip")

    @staticmethod
    def _axis(layout, settings, obj=None):
        box = layout.box()
        box.label(text="Axis")
        box.prop(settings, "axis_x", text="X")
        box.prop(settings, "axis_y", text="Y")
        box.prop(settings, "axis_z", text="Z")

        if obj is not None and _get_bone_binding(obj)[0] is not None:
            box.operator(
                ALX_OT_ObjectXPlaneManipulatorUseBoneAxis.bl_idname,
                text="Use Bone Axis",
                icon="BONE_DATA",
            )

    @staticmethod
    def _range(layout, settings):
        box = layout.box()
        box.label(text="Dataref Range")
        box.prop(settings, "v1min", text="Min")
        box.prop(settings, "v1max", text="Max")

    @staticmethod
    def _dataref(layout, settings, name):
        layout.prop(settings, name, text=name.replace("dataref", "Dataref "))


classes = (
    ALX_OT_ObjectXPlaneManipulatorInfo,
    ALX_OT_ObjectXPlaneManipulatorReset,
    ALX_OT_ObjectXPlaneManipulatorUseBoneAxis,
    ALX_PT_ObjectXPlaneManipulator,
)
