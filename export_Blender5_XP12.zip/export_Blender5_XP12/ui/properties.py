# =============================================================================
#
# Project : export_Blender5_XP12
# File    : ui/properties.py
#
# Company : Alex234 Design Studio
#
# Purpose (EN):
#     Property groups used by the exporter and per-bone X-Plane settings.
#
# Назначение (RU):
#     Группы свойств экспортёра и индивидуальные настройки костей X-Plane.
#
# Blender : 5.1+
# =============================================================================

import bpy

from bpy.types import PropertyGroup

from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
)

from ..utils.collection_utils import get_collection_items


# =============================================================================
# BONE KEYFRAME
# =============================================================================

class ALX_PG_BoneXPlaneKey(PropertyGroup):

    frame: FloatProperty(
        name="№ keyframe",
        description="Blender frame number",
        default=1.0,
    )

    dataref_value: FloatProperty(
        name="DatarefValue",
        description="Value supplied by the X-Plane Dataref",
        default=0.0,
    )

    bone_angle: FloatProperty(
        name="BoneAngle",
        description="Bone rotation angle in degrees",
        default=0.0,
    )


# =============================================================================
# BONE X-PLANE SETTINGS
# =============================================================================

class ALX_PG_BoneXPlane(PropertyGroup):

    animation_enabled: BoolProperty(
        name="Анимация",
        description="Включить X-Plane анимацию для этой кости",
        default=False,
    )

    dataref_name: StringProperty(
        name="Dataref Name",
        description="Dataref для X-Plane анимации этой кости",
        default="",
    )

    keyframes: CollectionProperty(
        name="Keyframes",
        type=ALX_PG_BoneXPlaneKey,
    )

    # This property is kept for compatibility with the existing operators.
    # IMPORTANT: never assign it from a Panel.draw() method.
    active_keyframe: IntProperty(
        name="Selected keyframe",
        default=-1,
        min=-1,
    )


# =============================================================================
# OBJECT X-PLANE MANIPULATOR
# =============================================================================

class ALX_PG_ObjectXPlaneManipulator(PropertyGroup):

    enabled: BoolProperty(
        name="Манипулятор",
        description="Включить X-Plane manipulator для этого объекта. Манипулятор действует на геометрию этого меша.",
        default=False,
    )

    type: EnumProperty(
        name="Type",
        items=(
            ("NONE", "None", "No manipulation"),
            ("DRAG_AXIS", "Drag Axis", "3-D axis dataref drag"),
            ("DRAG_XY", "Drag XY", "2-D screen-space dataref drag"),
            ("COMMAND", "Command", "Momentary command"),
            ("COMMAND_AXIS", "Command Axis", "Two-direction command axis"),
            ("PUSH", "Push", "Push button"),
            ("RADIO", "Radio", "Radio button"),
            ("TOGGLE", "Toggle", "Toggle dataref"),
            ("DRAG_ROTATE", "Drag Rotate", "Rotational manipulator"),
            ("COMMAND_KNOB", "Command Knob", "VR-friendly command knob"),
            ("COMMAND_SWITCH_UP_DOWN", "Command Switch Up/Down", "VR-friendly switch"),
            ("COMMAND_SWITCH_LEFT_RIGHT", "Command Switch Left/Right", "VR-friendly switch"),
            ("AXIS_KNOB", "Axis Knob", "Dataref-driven knob"),
            ("AXIS_SWITCH_UP_DOWN", "Axis Switch Up/Down", "Dataref-driven switch"),
            ("AXIS_SWITCH_LEFT_RIGHT", "Axis Switch Left/Right", "Dataref-driven switch"),
        ),
        default="NONE",
    )

    cursor: EnumProperty(
        name="Cursor",
        description="Курсор X-Plane, который показывается при наведении на меш.",
        items=(
            ("four_arrows", "four_arrows", "Курсор для перетаскивания по двум направлениям."),
            ("hand", "hand", "Курсор руки для обычного интерактивного элемента."),
            ("button", "button", "Курсор кнопки."),
            ("rotate_small", "rotate_small", "Малый курсор вращения."),
            ("rotate_medium", "rotate_medium", "Средний курсор вращения."),
            ("rotate_large", "rotate_large", "Большой курсор вращения."),
            ("up_down", "up_down", "Курсор перетаскивания вверх/вниз."),
            ("down", "down", "Курсор движения вниз."),
            ("up", "up", "Курсор движения вверх."),
            ("left_right", "left_right", "Курсор перетаскивания влево/вправо."),
            ("right", "right", "Курсор движения вправо."),
            ("left", "left", "Курсор движения влево."),
            ("arrow", "arrow", "Обычный курсор-стрелка."),
        ),
        default="hand",
    )

    dx: FloatProperty(name="DX", description="Длина перетаскивания по экранной оси X в пикселях.", default=100.0)
    dy: FloatProperty(name="DY", description="Длина перетаскивания по экранной оси Y в пикселях.", default=100.0)

    axis_x: FloatProperty(name="Axis X", description="X-компонента направления оси манипулятора в координатах OBJ/X-Plane.", default=0.0)
    axis_y: FloatProperty(name="Axis Y", description="Y-компонента направления оси манипулятора в координатах OBJ/X-Plane.", default=0.0)
    axis_z: FloatProperty(name="Axis Z", description="Z-компонента направления оси манипулятора в координатах OBJ/X-Plane.", default=1.0)

    origin_x: FloatProperty(name="Origin X", description="X-координата центра вращения манипулятора в координатах OBJ/X-Plane.", default=0.0)
    origin_y: FloatProperty(name="Origin Y", description="Y-координата центра вращения манипулятора в координатах OBJ/X-Plane.", default=0.0)
    origin_z: FloatProperty(name="Origin Z", description="Z-координата центра вращения манипулятора в координатах OBJ/X-Plane.", default=0.0)

    angle1: FloatProperty(name="Angle 1", description="Угол при минимальном значении Dataref 1, в градусах.", default=0.0)
    angle2: FloatProperty(name="Angle 2", description="Угол при максимальном значении Dataref 1, в градусах.", default=90.0)
    lift: FloatProperty(name="Lift", description="Подъём манипулятора от центра вращения для detent-механизма. Для обычного вращения оставьте 0.", default=0.0)

    v1: FloatProperty(name="Value 1", description="Значение Dataref при нажатии или включении.", default=1.0)
    v2: FloatProperty(name="Value 2", description="Второе значение Dataref: обычно значение при отпускании или выключении.", default=0.0)
    v1min: FloatProperty(name="Min 1", description="Минимальное значение первого Dataref.", default=0.0)
    v1max: FloatProperty(name="Max 1", description="Максимальное значение первого Dataref.", default=1.0)
    v2min: FloatProperty(name="Min 2", description="Минимальное значение второго Dataref.", default=0.0)
    v2max: FloatProperty(name="Max 2", description="Максимальное значение второго Dataref.", default=1.0)
    click_delta: FloatProperty(name="Click Delta", description="Изменение Dataref при одном клике.", default=1.0)
    hold_delta: FloatProperty(name="Hold Delta", description="Изменение Dataref при удержании кнопки/манипулятора.", default=1.0)

    dataref1: StringProperty(name="Dataref 1", description="Полное имя первого X-Plane DataRef, например sim/cockpit2/...", default="")
    dataref2: StringProperty(name="Dataref 2", description="Полное имя второго X-Plane DataRef. Для DRAG_ROTATE обычно не используется.", default="")
    command1: StringProperty(name="Command 1", description="Полное имя X-Plane command, например sim/...", default="")
    command2: StringProperty(name="Command 2", description="Второе X-Plane command для обратного направления.", default="")
    tooltip: StringProperty(name="Tooltip", description="Текст подсказки, который X-Plane показывает при наведении курсора на манипулятор.", default="")


# =============================================================================
# X-PLANE LIGHT
# =============================================================================

class ALX_PG_XPlaneLight(PropertyGroup):

    enabled: BoolProperty(
        name="Light",
        description="Export this Blender Light as an X-Plane 12 OBJ light.",
        default=False,
    )

    type: EnumProperty(
        name="Type",
        description="X-Plane OBJ light command.",
        items=(
            ("NONE", "None", "Do not export this light."),
            ("NAMED", "Named", "LIGHT_NAMED predefined X-Plane light."),
            ("PARAM", "Parameterized", "LIGHT_PARAM aircraft parameterized light."),
            ("CUSTOM", "Custom", "LIGHT_CUSTOM textured billboard light."),
            ("SPILL_CUSTOM", "Spill Custom", "LIGHT_SPILL_CUSTOM custom spill light."),
        ),
        default="NONE",
    )

    light_name: StringProperty(
        name="Light Name",
        description="Name of a predefined X-Plane named light.",
        default="",
    )

    parameterized_type: EnumProperty(
        name="Parameterized Light",
        description="X-Plane 12 aircraft parameterized light type.",
        items=(
            ("airplane_landing_core", "Landing Core", "Landing light bulb billboard."),
            ("airplane_landing_glow", "Landing Glow", "Landing light ambient glow billboard."),
            ("airplane_landing_flare", "Landing Flare", "Landing light star flare billboard."),
            ("airplane_landing_sp", "Landing Spill", "Landing light spill."),
            ("airplane_taxi_core", "Taxi Core", "Taxi light bulb billboard."),
            ("airplane_taxi_glow", "Taxi Glow", "Taxi light ambient glow billboard."),
            ("airplane_taxi_flare", "Taxi Flare", "Taxi light star flare billboard."),
            ("airplane_taxi_sp", "Taxi Spill", "Taxi light spill."),
            ("airplane_spot_core", "Spot Core", "Spot light bulb billboard."),
            ("airplane_spot_glow", "Spot Glow", "Spot light ambient glow billboard."),
            ("airplane_spot_flare", "Spot Flare", "Spot light star flare billboard."),
            ("airplane_spot_sp", "Spot Spill", "Spot light spill."),
            ("airplane_generic_core", "Generic Core", "Generic light bulb billboard."),
            ("airplane_generic_glow", "Generic Glow", "Generic light ambient glow billboard."),
            ("airplane_generic_flare", "Generic Flare", "Generic light star flare billboard."),
            ("airplane_generic_sp", "Generic Spill", "Generic light spill."),
            ("airplane_beacon_rotate", "Beacon Rotate", "Rotating beacon billboard."),
            ("airplane_beacon_rotate_sp", "Beacon Rotate Spill", "Rotating beacon spill."),
            ("airplane_beacon_strobe", "Beacon Strobe", "Strobing beacon billboard."),
            ("airplane_beacon_strobe_sp", "Beacon Strobe Spill", "Strobing beacon spill."),
            ("airplane_strobe_omni", "Strobe Omni", "Omnidirectional anti-collision strobe billboard."),
            ("airplane_strobe_dir", "Strobe Directional", "Directional anti-collision strobe billboard."),
            ("airplane_strobe_sp", "Strobe Spill", "Anti-collision strobe spill."),
            ("airplane_nav_tail_size", "Nav Tail", "White tail navigation billboard."),
            ("airplane_nav_left_size", "Nav Left", "Red left navigation billboard."),
            ("airplane_nav_right_size", "Nav Right", "Green right navigation billboard."),
            ("airplane_nav_sp", "Nav Spill", "Navigation spill."),
            ("airplane_panel_sp", "Panel Spill", "Cockpit panel/flood spill."),
            ("airplane_inst_sp", "Instrument Spill", "Cockpit instrument spill."),
        ),
        default="airplane_landing_core",
    )

    # Up to 12 parameters are enough for all current X-Plane 12 aircraft
    # parameterized lights. The UI assigns the documented names dynamically.
    param1: FloatProperty(name="Param 1", default=0.0)
    param2: FloatProperty(name="Param 2", default=0.0)
    param3: FloatProperty(name="Param 3", default=0.0)
    param4: FloatProperty(name="Param 4", default=0.0)
    param5: FloatProperty(name="Param 5", default=0.0)
    param6: FloatProperty(name="Param 6", default=0.0)
    param7: FloatProperty(name="Param 7", default=0.0)
    param8: FloatProperty(name="Param 8", default=0.0)
    param9: FloatProperty(name="Param 9", default=0.0)
    param10: FloatProperty(name="Param 10", default=0.0)
    param11: FloatProperty(name="Param 11", default=0.0)
    param12: FloatProperty(name="Param 12", default=0.0)

    red: FloatProperty(name="R", description="Red component, 0..1.", default=1.0, min=0.0, max=1.0)
    green: FloatProperty(name="G", description="Green component, 0..1.", default=1.0, min=0.0, max=1.0)
    blue: FloatProperty(name="B", description="Blue component, 0..1.", default=1.0, min=0.0, max=1.0)
    alpha: FloatProperty(name="A", description="Alpha/brightness component, 0..1.", default=1.0, min=0.0, max=1.0)

    size: FloatProperty(name="Size", description="Light size. For spill lights this is meters to complete attenuation.", default=1.0, min=0.0)

    s1: FloatProperty(name="S1", description="Custom light texture S coordinate, 0..1.", default=0.0, min=0.0, max=1.0)
    t1: FloatProperty(name="T1", description="Custom light texture T coordinate, 0..1.", default=0.0, min=0.0, max=1.0)
    s2: FloatProperty(name="S2", description="Custom light texture S coordinate, 0..1.", default=1.0, min=0.0, max=1.0)
    t2: FloatProperty(name="T2", description="Custom light texture T coordinate, 0..1.", default=1.0, min=0.0, max=1.0)

    direction_x: FloatProperty(name="Direction X", description="Spill direction X component in OBJ/X-Plane coordinates.", default=0.0)
    direction_y: FloatProperty(name="Direction Y", description="Spill direction Y component in OBJ/X-Plane coordinates.", default=0.0)
    direction_z: FloatProperty(name="Direction Z", description="Spill direction Z component in OBJ/X-Plane coordinates.", default=0.0)

    semi: FloatProperty(name="Semi", description="Cosine of half cone angle. Use 1.0 for omni-directional spill.", default=1.0, min=0.0, max=1.0)

    dataref: StringProperty(
        name="Dataref",
        description="Optional X-Plane DataRef for custom light parameters.",
        default="none",
    )


# =============================================================================
# X-PLANE MATERIAL
# =============================================================================

class ALX_PG_XPlaneMaterial(PropertyGroup):

    glass: BoolProperty(
        name="Glass",
        description=(
            "Treat geometry using this material as X-Plane glass. "
            "The exporter writes BLEND_GLASS and places the geometry into a "
            "separate glass export group. The resulting OBJ must be attached "
            "in Plane Maker using a Glass lighting/draw mode."
        ),
        default=False,
    )


# =============================================================================
# EXPORT SETTINGS
# =============================================================================

class ALX_PG_ExportSettings(PropertyGroup):

    log_enabled: BoolProperty(
        name="Лог",
        description="Записывать лог-файл при экспорте",
        default=False,
    )

    texture_normal_enabled: BoolProperty(
        name="Добавить файл нормалей",
        description="Добавлять TEXTURE_NORMAL с именем основной текстуры + _NRM",
        default=False,
    )

    texture_lit_enabled: BoolProperty(
        name="Добавить файл Lit",
        description="Добавлять TEXTURE_LIT с именем основной текстуры + _LIT",
        default=False,
    )

    export_collection: EnumProperty(
        name="Collection",
        description="Collection to export",
        items=get_collection_items,
    )
