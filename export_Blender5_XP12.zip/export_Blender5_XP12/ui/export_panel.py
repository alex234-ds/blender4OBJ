# =============================================================================
# Project : export_Blender5_XP12
# File    : ui/export_panel.py
#
# Company : Alex234 Design Studio
#
# Purpose (EN):
#     Main user interface panel for the X-Plane exporter.
#
# Назначение (RU):
#     Главная панель пользовательского интерфейса экспортёра.
#
# Blender : 5.1+
# =============================================================================

import bpy


class ALX_PT_Export(bpy.types.Panel):

    """
    Main X-Plane exporter panel.
    """

    bl_label = "X-Plane Exporter"
    bl_idname = "ALX_PT_export"

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Alex234"

    def draw(
        self,
        context,
    ):

        layout = self.layout

        settings = (
            context.scene.alx_export_settings
        )

        layout.label(
            text="Alex234 Design Studio"
        )

        layout.separator()

        layout.prop(
            settings,
            "export_collection",
            text="Collection"
        )

        layout.separator()

        layout.prop(
            settings,
            "texture_normal_enabled",
            text="Добавить файл нормалей",
        )

        layout.prop(
            settings,
            "texture_lit_enabled",
            text="Добавить файл Lit",
        )

        row = layout.row(align=True)

        row.prop(
            settings,
            "log_enabled",
            text="Лог",
        )

        row.operator(
            "export_scene.xplane_obj12",
            text="Export OBJ",
            icon='EXPORT'
        )
