# =============================================================================
# Project : export_Blender5_XP12
# File    : utils/collection_utils.py
#
# Company : Alex234 Design Studio
#
# Purpose (EN):
#     Collection helper functions.
#
# Назначение (RU):
#     Вспомогательные функции для работы с коллекциями Blender.
#
# Blender : 5.1+
# =============================================================================

import bpy


def get_collection_items(self, context):
    """
    Returns a list of collections for EnumProperty.
    """

    items = []

    for collection in bpy.data.collections:
        items.append(
            (
                collection.name,
                collection.name,
                ""
            )
        )

    if not items:
        items.append(
            (
                "NONE",
                "<No Collections>",
                ""
            )
        )

    return items


def get_collection_by_name(name):
    """
    Returns Blender collection by its name.
    """

    return bpy.data.collections.get(name)
