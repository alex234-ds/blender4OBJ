# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_material_writer.py
# =============================================================================

class ALX_OBJMaterialWriter:

    def write(self, file, scene):
        if getattr(scene, "glass", False):
            file.write("BLEND_GLASS\n")

