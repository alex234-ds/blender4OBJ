# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_point_counts_writer.py
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJPointCountsWriter:

    def write(
        self,
        file,
        scene,
    ):

        vt_count = len(
            scene.vt_table
        )

        line_count = 0

        light_count = len(
            scene.lights
        )

        idx_count = len(
            scene.idx_table
        )

        file.write(

            f"{ALX_OBJTokens.POINT_COUNTS} "

            f"{vt_count} "

            f"{line_count} "

            f"{light_count} "

            f"{idx_count}\n"

        )
