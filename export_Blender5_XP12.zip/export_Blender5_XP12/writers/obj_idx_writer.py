# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_idx_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes IDX table.
#
# Назначение (RU):
#     Запись таблицы IDX.
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJIDXWriter:

    def write(
        self,
        file,
        scene,
    ):

        indices = scene.idx_table

        full_groups = len(indices) // 10

        remainder = len(indices) % 10

        #
        # IDX10
        #

        for group in range(full_groups):

            start = group * 10

            values = indices[start:start + 10]

            file.write(

                f"{ALX_OBJTokens.IDX10} "

                + " ".join(

                    str(v)

                    for v in values

                )

                + "\n"

            )

        #
        # Remaining IDX
        #

        if remainder:

            start = full_groups * 10

            for value in indices[start:]:

                file.write(

                    f"{ALX_OBJTokens.IDX} {value}\n"

                )
