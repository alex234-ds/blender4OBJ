# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_vt_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes VT table.
#
# Назначение (RU):
#     Запись таблицы VT.
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJVTWriter:
    """
    Writes VT records.
    """

    def write(
        self,
        file,
        scene,
    ):

        for vt in scene.vt_table:

            file.write(

                f"{ALX_OBJTokens.VT} "

                f"{vt['x']:.6f} "

                f"{vt['y']:.6f} "

                f"{vt['z']:.6f} "

                f"{vt['nx']:.6f} "

                f"{vt['ny']:.6f} "

                f"{vt['nz']:.6f} "

                f"{vt['u']:.6f} "

                f"{vt['v']:.6f}\n"

            )
