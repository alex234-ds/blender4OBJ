# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_light_writer.py
#
# Purpose:
#     Write modern X-Plane OBJ light commands.
# =============================================================================

import math

from .obj_tokens import ALX_OBJTokens
from ..core.xplane_lights import PARAM_DEFS


class ALX_OBJLightWriter:

    def write(
        self,
        file,
        lights,
        texture=None,
    ):

        for obj in lights or []:
            settings = getattr(obj, "alx_xplane_light", None)
            if settings is None or not settings.enabled:
                continue

            light_type = settings.type
            if light_type == "NONE":
                continue

            position = self._xplane_position(obj)

            if light_type == "NAMED":
                name = self._text(settings.light_name)
                if name:
                    file.write(
                        f"{ALX_OBJTokens.LIGHT_NAMED} {name} "
                        f"{position[0]:.6f} {position[1]:.6f} {position[2]:.6f}\n"
                    )

            elif light_type == "PARAM":
                name = self._text(getattr(settings, "parameterized_type", ""))
                if name:
                    defs = PARAM_DEFS.get(name, [])
                    values = []
                    for index, (label, default) in enumerate(defs, 1):
                        value = float(getattr(settings, f"param{index}", default))
                        if label == "INDEX":
                            value = max(0.0, round(value))
                        if name == "airplane_strobe_omni" and label in {"I1", "I2", "I3"}:
                            value = 0.0
                        values.append(f"{value:.6f}")
                    suffix = (" " + " ".join(values)) if values else ""
                    file.write(
                        f"{ALX_OBJTokens.LIGHT_PARAM} {name} "
                        f"{position[0]:.6f} {position[1]:.6f} {position[2]:.6f}"
                        f"{suffix}\n"
                    )

            elif light_type == "CUSTOM":
                if not texture:
                    print(
                        "[export_Blender5_XP12] "
                        f"Skipping LIGHT_CUSTOM for '{obj.name}': "
                        "OBJ texture is empty."
                    )
                    continue

                file.write(
                    f"{ALX_OBJTokens.LIGHT_CUSTOM} "
                    f"{position[0]:.6f} {position[1]:.6f} {position[2]:.6f} "
                    f"{settings.red:.6f} {settings.green:.6f} {settings.blue:.6f} {settings.alpha:.6f} "
                    f"{settings.size:.6f} "
                    f"{settings.s1:.6f} {settings.t1:.6f} {settings.s2:.6f} {settings.t2:.6f} "
                    f"{self._text(settings.dataref) or 'NULL'}\n"
                )

            elif light_type == "SPILL_CUSTOM":
                direction = self._spill_direction(obj, settings)
                file.write(
                    f"{ALX_OBJTokens.LIGHT_SPILL_CUSTOM} "
                    f"{position[0]:.6f} {position[1]:.6f} {position[2]:.6f} "
                    f"{settings.red:.6f} {settings.green:.6f} {settings.blue:.6f} {settings.alpha:.6f} "
                    f"{settings.size:.6f} "
                    f"{direction[0]:.6f} {direction[1]:.6f} {direction[2]:.6f} "
                    f"{settings.semi:.6f} "
                    f"{self._text(settings.dataref) or 'none'}\n"
                )

    @staticmethod
    def _xplane_position(obj):
        co = obj.matrix_world.translation
        return float(co.x), float(co.z), float(-co.y)

    @staticmethod
    def _spill_direction(obj, settings):
        # If the user supplied a direction, preserve it. Otherwise use the
        # Blender Light object's local -Z direction converted to OBJ space.
        length = math.sqrt(
            settings.direction_x ** 2
            + settings.direction_y ** 2
            + settings.direction_z ** 2
        )

        if length > 1.0e-12:
            return (
                settings.direction_x / length,
                settings.direction_y / length,
                settings.direction_z / length,
            )

        direction_blender = obj.matrix_world.to_3x3() @ (0.0, 0.0, -1.0)
        x = direction_blender.x
        y = direction_blender.z
        z = -direction_blender.y
        length = math.sqrt(x*x + y*y + z*z)

        if length <= 1.0e-12:
            return 0.0, 0.0, 0.0

        return x / length, y / length, z / length

    @staticmethod
    def _text(value):
        return str(value or "").replace("\n", " ").strip()
