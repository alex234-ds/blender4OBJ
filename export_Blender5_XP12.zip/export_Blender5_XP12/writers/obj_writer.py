# =============================================================================
#
# Project : export_Blender5_XP12
# File    : writers/obj_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Main OBJ8 file writer.
#
# Назначение (RU):
#     Главный координатор записи OBJ8-файлов.
#
# Blender : 5.1+
#
# IMPORTANT:
#     OBJ8 animation commands must be immediately after ANIM_begin.
#     TRIS geometry affected by the animation must be inside
#     ANIM_begin / ANIM_end.
# =============================================================================

from pathlib import Path

from .obj_header_writer import ALX_OBJHeaderWriter
from .obj_texture_writer import ALX_OBJTextureWriter
from .obj_material_writer import ALX_OBJMaterialWriter
from .obj_point_counts_writer import ALX_OBJPointCountsWriter
from .obj_vt_writer import ALX_OBJVTWriter
from .obj_idx_writer import ALX_OBJIDXWriter
from .obj_tris_writer import ALX_OBJTRISWriter
from .obj_anim_writer import ALX_OBJAnimWriter
from .obj_light_writer import ALX_OBJLightWriter


class ALX_OBJWriter:

    def __init__(
        self,
        filepath,
    ):

        self.filepath = filepath

        self.header_writer = (
            ALX_OBJHeaderWriter()
        )

        self.texture_writer = (
            ALX_OBJTextureWriter()
        )

        self.material_writer = (
            ALX_OBJMaterialWriter()
        )

        self.point_counts_writer = (
            ALX_OBJPointCountsWriter()
        )

        self.vt_writer = (
            ALX_OBJVTWriter()
        )

        self.idx_writer = (
            ALX_OBJIDXWriter()
        )

        self.tris_writer = (
            ALX_OBJTRISWriter()
        )

        self.anim_writer = (
            ALX_OBJAnimWriter()
        )

        self.light_writer = (
            ALX_OBJLightWriter()
        )

    # =========================================================================
    # WRITE
    # =========================================================================

    def write(
        self,
        scene,
    ):

        groups = scene.export_groups

        print(
            "[export_Blender5_XP12] "
            f"OBJ files to write: {len(groups)}"
        )

        if not groups:

            self._write_single(
                self.filepath,
                scene,
            )

            print(
                "[export_Blender5_XP12] "
                f"OBJ written: {self.filepath}"
            )

            return [
                self.filepath
            ]

        if len(groups) == 1:

            group = groups[0]

            self._write_group(
                self.filepath,
                scene,
                group,
            )

            self._log_group(
                self.filepath,
                group,
            )

            return [
                self.filepath
            ]

        base_path = Path(
            self.filepath
        )

        output_files = []

        # Keep the user-selected filename for the first ordinary group.
        # Glass gets a clear, deterministic suffix instead of an opaque
        # numeric group id. Additional material groups use the texture stem
        # to remain distinguishable.
        ordinary_index = 0
        glass_index = 0
        used_names = set()

        for group in groups:

            is_glass = bool(group.get("glass", False))
            texture = str(group.get("texture") or "").strip()
            texture_stem = Path(texture).stem if texture else "no-texture"

            if not is_glass and ordinary_index == 0:
                output_name = (
                    f"{base_path.stem}{base_path.suffix}"
                )
                ordinary_index += 1
            elif is_glass and glass_index == 0:
                output_name = (
                    f"{base_path.stem}-glass{base_path.suffix}"
                )
                glass_index += 1
            else:
                suffix = f"-{texture_stem}"
                if is_glass:
                    suffix += "-glass"
                output_name = (
                    f"{base_path.stem}{suffix}{base_path.suffix}"
                )

            # Avoid collisions when several source textures share the same
            # stem or when the user-selected filename already matches one of
            # the generated names.
            candidate = output_name
            counter = 2
            while candidate.lower() in used_names:
                candidate = (
                    f"{Path(output_name).stem}-{counter}"
                    f"{Path(output_name).suffix}"
                )
                counter += 1

            output_name = candidate
            used_names.add(output_name.lower())

            output_path = base_path.with_name(output_name)

            output_path = str(
                output_path
            )

            self._write_group(
                output_path,
                scene,
                group,
            )

            output_files.append(
                output_path
            )

            self._log_group(
                output_path,
                group,
            )

        return output_files

    # =========================================================================
    # SINGLE / LEGACY
    # =========================================================================

    def _write_single(
        self,
        filepath,
        scene,
    ):

        has_animation = (
            self.anim_writer.has_animation(
                scene
            )
        )

        with open(
            filepath,
            "w",
            encoding="utf-8",
            newline="\n",
        ) as file:

            self.header_writer.write(
                file
            )

            self.texture_writer.write(
                file,
                scene,
            )

            self.material_writer.write(
                file,
                scene,
            )

            self.point_counts_writer.write(
                file,
                scene,
            )

            self.vt_writer.write(
                file,
                scene,
            )

            self.idx_writer.write(
                file,
                scene,
            )

            self.light_writer.write(
                file,
                getattr(scene, "lights", []),
                getattr(scene, "texture", None),
            )

            #
            # IMPORTANT:
            # ANIM_begin must be immediately followed by
            # animation commands. TRIS comes after them.
            #

            if has_animation:

                self.anim_writer.write_begin(
                    file
                )

                self.anim_writer.write_commands(
                    file,
                    scene,
                )

            self.tris_writer.write(
                file,
                scene,
            )

            if has_animation:

                self.anim_writer.write_end(
                    file
                )

    # =========================================================================
    # GROUP
    # =========================================================================

    def _write_group(
        self,
        filepath,
        scene,
        group,
    ):

        export_scene = (
            self._make_group_scene(
                scene,
                group,
            )
        )

        has_animation = (
            self.anim_writer.has_animation(
                export_scene
            )
        )

        with open(
            filepath,
            "w",
            encoding="utf-8",
            newline="\n",
        ) as file:

            self.header_writer.write(
                file
            )

            self.texture_writer.write(
                file,
                export_scene,
            )

            self.material_writer.write(
                file,
                export_scene,
            )

            self.point_counts_writer.write(
                file,
                export_scene,
            )

            self.vt_writer.write(
                file,
                export_scene,
            )

            self.idx_writer.write(
                file,
                export_scene,
            )

            self.light_writer.write(
                file,
                getattr(export_scene, "lights", []),
                getattr(export_scene, "texture", None),
            )

            #
            # OBJ8 animation scope:
            #
            # ANIM_begin
            #   ANIM_trans +pivot
            #   ANIM_rotate_begin/key/end
            #   ANIM_trans -pivot
            #   TRIS ...
            # ANIM_end
            #
            # Animation commands must remain before TRIS.
            #

            if has_animation:

                print(
                    "[export_Blender5_XP12] "
                    "Writing animation block before TRIS"
                )

                self.anim_writer.write_begin(
                    file
                )

                self.anim_writer.write_commands(
                    file,
                    export_scene,
                )

            self.tris_writer.write(
                file,
                export_scene,
            )

            if has_animation:

                self.anim_writer.write_end(
                    file
                )

    # =========================================================================
    # GROUP LOG
    # =========================================================================

    def _log_group(
        self,
        filepath,
        group,
    ):

        texture = (
            group.get(
                "texture"
            )
        )

        if texture:
            texture_text = texture
        else:
            texture_text = "<none>"

        print(
            "[export_Blender5_XP12] "
            f"OBJ: {Path(filepath).name}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  Texture: {texture_text}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  Glass: {bool(group.get('glass', False))}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  Objects: "
            f"{len(group['objects'])}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  VT: "
            f"{len(group['vt_table'])}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  IDX: "
            f"{len(group['idx_table'])}"
        )

        print(
            "[export_Blender5_XP12] "
            f"  TRIS: "
            f"{len(group['tris_table'])}"
        )

    # =========================================================================
    # GROUP SCENE
    # =========================================================================

    def _make_group_scene(
        self,
        scene,
        group,
    ):

        class ALX_OBJGroupScene:
            pass

        export_scene = (
            ALX_OBJGroupScene()
        )

        export_scene.texture = (
            group["texture"]
        )

        export_scene.glass = bool(
            group.get("glass", False)
        )

        export_scene.texture_lit = (
            group.get(
                "texture_lit"
            )
        )

        export_scene.texture_normal = (
            group.get(
                "texture_normal"
            )
        )

        export_scene.vt_table = (
            group["vt_table"]
        )

        export_scene.idx_table = (
            group["idx_table"]
        )

        export_scene.tris_table = (
            group["tris_table"]
        )

        # Lights are global OBJ records, but must not be duplicated into
        # every material-split OBJ. Keep unparented lights in the first
        # ordinary object; bone-parented lights follow the corresponding
        # geometry group when that relationship can be resolved.
        export_scene.lights = []

        is_primary_group = bool(
            scene.export_groups
            and group is scene.export_groups[0]
        )

        if is_primary_group:
            for light in getattr(scene, "lights", []):
                parent = getattr(light, "parent", None)
                parent_type = getattr(light, "parent_type", "")

                if parent is None or parent_type not in {"BONE", "BONE_RELATIVE"}:
                    export_scene.lights.append(light)

        group_bone_names = set(group.get("bone_names", []))

        if group_bone_names:
            for light in getattr(scene, "lights", []):
                parent = getattr(light, "parent", None)
                parent_type = getattr(light, "parent_type", "")
                bone_name = str(getattr(light, "parent_bone", "") or "").strip()

                if (
                    parent is not None
                    and parent_type in {"BONE", "BONE_RELATIVE"}
                    and bone_name in group_bone_names
                ):
                    export_scene.lights.append(light)

        # ---------------------------------------------------------------------
        # Animation data.
        # ---------------------------------------------------------------------

        group_bone_names = set(
            group.get("bone_names", [])
        )

        export_scene.bones = [
            bone
            for bone in getattr(scene, "bones", [])
            if bone.get("name", "") in group_bone_names
            and bone.get("animation", [])
        ]

        # ---------------------------------------------------------------------
        # IMPORTANT:
        #
        # The animation writer needs the original Armature Object in order
        # to transform:
        #
        #     bone.head_local
        #
        # into OBJ/Mesh coordinates.
        #
        # Previously this information was lost when creating the temporary
        # group scene. That caused:
        #
        #     Armature object NOT FOUND
        #
        # and therefore the pivot remained (0, 0, 0).
        # ---------------------------------------------------------------------

        export_scene.armature_data = getattr(
            scene,
            "armature_data",
            None,
        )

        # ---------------------------------------------------------------------
        # Objects belonging to this export group.
        #
        # The animation writer uses the Mesh Object transform to convert
        # the bone head from Armature coordinates into Mesh/OBJ coordinates.
        # ---------------------------------------------------------------------

        export_scene.export_objects = (
            group.get(
                "objects",
                [],
            )
        )

        # ---------------------------------------------------------------------
        # Blender FPS is needed to convert
        # Blender frame numbers to X-Plane seconds.
        # ---------------------------------------------------------------------

        export_scene.fps = float(
            getattr(
                scene,
                "fps",
                24.0,
            )
        )

        return export_scene
