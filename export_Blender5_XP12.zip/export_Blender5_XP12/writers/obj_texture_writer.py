# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_texture_writer.py
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJTextureWriter:

    def write(
        self,
        file,
        scene,
    ):

        #
        # TEXTURE
        #

        if scene.texture:

            file.write(

                f"{ALX_OBJTokens.TEXTURE} "
                f"{scene.texture}\n"

            )

        else:

            file.write(

                f"{ALX_OBJTokens.TEXTURE}\n"

            )

        #
        # TEXTURE_LIT
        #

        if scene.texture_lit:

            file.write(

                f"{ALX_OBJTokens.TEXTURE_LIT} "
                f"{scene.texture_lit}\n"

            )

        #
        # TEXTURE_NORMAL
        #

        if scene.texture_normal:

            file.write(

                f"{ALX_OBJTokens.TEXTURE_NORMAL} "
                f"{scene.texture_normal}\n"

            )

        file.write("\n")
