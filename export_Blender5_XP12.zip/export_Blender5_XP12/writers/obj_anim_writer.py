# =============================================================================
#
# Project : export_Blender5_XP12
# File    : writers/obj_anim_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes OBJ8 animation commands.
#
# Назначение (RU):
#     Запись команд анимации OBJ8.
#
# IMPORTANT:
#     OBJ8 requires ANIM_rotate_begin/key/end immediately after ANIM_begin.
#     Geometry (TRIS) must follow the animation commands and remain inside
#     the ANIM_begin / ANIM_end block.
#
# COORDINATE SYSTEM:
#
#     Blender:
#         X = X
#         Y = Y
#         Z = Z
#
#     X-Plane:
#         X = Blender X
#         Y = Blender Z
#         Z = -Blender Y
#
# IMPORTANT:
#
#     obj_vt_writer.py does NOT transform coordinates.
#
#     mesh_builder.py already writes VT coordinates as:
#
#         x = world.x
#         y = world.z
#         z = -world.y
#
#     Therefore animation pivot MUST use the same coordinate space:
#
#         Blender world
#             ->
#         X-Plane world
#
#     DO NOT convert the pivot into Mesh local coordinates.
#
#     The same applies to the rotation axis:
#
#         Blender bone local
#             ->
#         Armature world
#             ->
#         X-Plane
#
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJAnimWriter:

    # =========================================================================
    # HAS ANIMATION
    # =========================================================================

    def has_animation(
        self,
        scene,
    ):

        bones = getattr(
            scene,
            "bones",
            [],
        )

        for bone in bones:

            animation = bone.get(
                "animation",
                [],
            )

            if animation:
                return True

        return False

    # =========================================================================
    # BEGIN
    # =========================================================================

    def write_begin(
        self,
        file,
    ):

        file.write(
            f"{ALX_OBJTokens.ANIM_BEGIN}\n"
        )

    # =========================================================================
    # ANIMATION COMMANDS
    # =========================================================================

    def write_commands(
        self,
        file,
        scene,
    ):

        bones = getattr(
            scene,
            "bones",
            [],
        )

        if not bones:
            return

        fps = float(
            getattr(
                scene,
                "fps",
                24.0,
            )
        )

        if fps <= 0.0:

            fps = 24.0

        for bone in bones:

            animation = bone.get(
                "animation",
                [],
            )

            if not animation:
                continue

            self._write_bone(
                file,
                bone,
                fps,
                scene,
            )

    # =========================================================================
    # END
    # =========================================================================

    def write_end(
        self,
        file,
    ):

        file.write(
            f"{ALX_OBJTokens.ANIM_END}\n"
        )

    # =========================================================================
    # LEGACY FULL WRITE
    # =========================================================================

    def write(
        self,
        file,
        scene,
    ):

        if not self.has_animation(
            scene
        ):

            return

        self.write_begin(
            file
        )

        self.write_commands(
            file,
            scene
        )

        self.write_end(
            file
        )

        file.write(
            "\n"
        )

    # =========================================================================
    # BONE
    # =========================================================================

    def _write_bone(
        self,
        file,
        bone,
        fps,
        scene,
    ):

        name = bone.get(
            "name",
            "",
        )

        animation = bone.get(
            "animation",
            [],
        )

        if not animation:
            return

        # ---------------------------------------------------------------------
        # ROTATION AXIS
        # ---------------------------------------------------------------------
        #
        # The collector stores the bone axis in Armature local coordinates.
        #
        # We MUST NOT simply swap Y/Z here if the Armature object has a
        # transform.
        #
        # Correct transformation:
        #
        #     bone local
        #          ->
        #     Armature world
        #          ->
        #     X-Plane
        #
        # ---------------------------------------------------------------------

        (
            axis_x,
            axis_y,
            axis_z,
        ) = self._get_bone_axis_xplane(
            bone,
            scene,
        )

        # ---------------------------------------------------------------------
        # PIVOT
        # ---------------------------------------------------------------------
        #
        # IMPORTANT:
        #
        # mesh_builder.py creates VT records from:
        #
        #     co = mesh_object.matrix_world @ vertex.co
        #
        # and then:
        #
        #     X = co.x
        #     Y = co.z
        #     Z = -co.y
        #
        # Therefore the animation pivot must also be expressed as
        # X-Plane WORLD coordinates.
        #
        # DO NOT use:
        #
        #     mesh_object.matrix_world.inverted()
        #
        # because that would produce Mesh LOCAL coordinates, while VT is
        # already WORLD coordinates.
        #
        (
            pivot_x,
            pivot_y,
            pivot_z,
        ) = self._get_pivot(
            bone,
            scene,
        )

        print(
            "[export_Blender5_XP12] "
            f"Animation pivot: "
            f"bone={name} "
            f"pivot=("
            f"{pivot_x:.6f}, "
            f"{pivot_y:.6f}, "
            f"{pivot_z:.6f})"
        )

        print(
            "[export_Blender5_XP12] "
            f"Animation axis XP: "
            f"bone={name} "
            f"axis=("
            f"{axis_x:.6f}, "
            f"{axis_y:.6f}, "
            f"{axis_z:.6f})"
        )

        # ---------------------------------------------------------------------
        # DATAREF
        # ---------------------------------------------------------------------

        # DataRef is configured individually on the Blender bone in
        # Bone Properties -> X-Plane.  The collector copies it into the
        # export bone record.  An empty DataRef means that this bone has no
        # exportable animation.

        dataref = str(
            bone.get(
                "dataref",
                "",
            )
        ).strip()

        if not dataref:
            return

        file.write(
            f"# BONE {name}\n"
        )

        # ---------------------------------------------------------------------
        # MOVE GEOMETRY TO ROTATION PIVOT
        # ---------------------------------------------------------------------
        #
        # OBJ8 animation:
        #
        #     +pivot
        #     rotate
        #     -pivot
        #
        # The pivot is in the SAME coordinate system as VT.
        #

        file.write(
            f"ANIM_trans "
            f"{pivot_x:.6f} "
            f"{pivot_y:.6f} "
            f"{pivot_z:.6f} "
            f"{pivot_x:.6f} "
            f"{pivot_y:.6f} "
            f"{pivot_z:.6f} "
            f"0.000000 "
            f"0.000000 "
            f"no_ref\n"
        )

        # ---------------------------------------------------------------------
        # ROTATION
        # ---------------------------------------------------------------------

        file.write(
            f"ANIM_rotate_begin "
            f"{axis_x:.6f} "
            f"{axis_y:.6f} "
            f"{axis_z:.6f} "
            f"{dataref}\n"
        )

        for key in animation:

            # -----------------------------------------------------------------
            # OBJ8 ANIM_rotate_key syntax:
            #
            #     ANIM_rotate_key <DatarefValue> <BoneAngle>
            #
            # The Blender frame number is NOT written to OBJ8. It is only
            # the row identifier used by the Blender UI / Auto import.
            # -----------------------------------------------------------------

            dataref_value = float(
                key.get(
                    "dataref_value",
                    0.0,
                )
            )

            bone_angle = float(
                key.get(
                    "bone_angle",
                    0.0,
                )
            )

            file.write(
                f"ANIM_rotate_key "
                f"{dataref_value:.6f} "
                f"{bone_angle:.6f}\n"
            )

        file.write(
            "ANIM_rotate_end\n"
        )

        # ---------------------------------------------------------------------
        # RESTORE ORIGINAL POSITION
        # ---------------------------------------------------------------------

        file.write(
            f"ANIM_trans "
            f"{-pivot_x:.6f} "
            f"{-pivot_y:.6f} "
            f"{-pivot_z:.6f} "
            f"{-pivot_x:.6f} "
            f"{-pivot_y:.6f} "
            f"{-pivot_z:.6f} "
            f"0.000000 "
            f"0.000000 "
            f"no_ref\n"
        )

    # =========================================================================
    # BONE AXIS -> X-PLANE
    # =========================================================================

    def _get_bone_axis_xplane(
        self,
        bone,
        scene,
    ):

        bone_name = bone.get(
            "name",
            "",
        )

        # ---------------------------------------------------------------------
        # Find actual Armature Object.
        # ---------------------------------------------------------------------

        armature_object = (
            self._find_armature_object(
                bone_name
            )
        )

        if armature_object is None:

            print(
                "[export_Blender5_XP12] "
                f"Animation axis: "
                f"bone={bone_name} "
                f"Armature object NOT FOUND"
            )

            # Fallback to collector axis.

            axis = bone.get(
                "axis",
                None,
            )

            if axis is None:

                return (
                    0.0,
                    0.0,
                    1.0,
                )

            return self._normalize_xplane_vector(
                float(
                    axis.get(
                        "x",
                        0.0,
                    )
                ),
                float(
                    axis.get(
                        "y",
                        0.0,
                    )
                ),
                float(
                    axis.get(
                        "z",
                        1.0,
                    )
                ),
            )

        armature_data = (
            armature_object.data
        )

        blender_bone = (
            armature_data.bones.get(
                bone_name
            )
        )

        if blender_bone is None:

            print(
                "[export_Blender5_XP12] "
                f"Animation axis: "
                f"bone={bone_name} "
                f"Blender bone NOT FOUND"
            )

            return (
                0.0,
                0.0,
                1.0,
            )

        # ---------------------------------------------------------------------
        # Bone direction in Armature local coordinates.
        # ---------------------------------------------------------------------

        head_local = (
            blender_bone.head_local
        )

        tail_local = (
            blender_bone.tail_local
        )

        axis_local = (
            tail_local
            - head_local
        )

        if axis_local.length <= 1.0e-12:

            return (
                0.0,
                0.0,
                1.0,
            )

        axis_local.normalize()

        # ---------------------------------------------------------------------
        # Armature local -> World.
        #
        # Direction vectors must use the 3x3 part only.
        # Translation must NOT affect an axis.
        # ---------------------------------------------------------------------

        axis_world = (
            armature_object.matrix_world.to_3x3()
            @ axis_local
        )

        if axis_world.length <= 1.0e-12:

            return (
                0.0,
                0.0,
                1.0,
            )

        axis_world.normalize()

        print(
            "[export_Blender5_XP12] "
            f"Animation axis Blender world: "
            f"bone={bone_name} "
            f"axis=("
            f"{axis_world.x:.6f}, "
            f"{axis_world.y:.6f}, "
            f"{axis_world.z:.6f})"
        )

        # ---------------------------------------------------------------------
        # Blender world -> X-Plane world.
        #
        #     XP X = Blender X
        #     XP Y = Blender Z
        #     XP Z = -Blender Y
        # ---------------------------------------------------------------------

        return self._normalize_xplane_vector(
            axis_world.x,
            axis_world.y,
            axis_world.z,
        )

    # =========================================================================
    # BLENDER WORLD VECTOR -> X-PLANE VECTOR
    # =========================================================================

    def _normalize_xplane_vector(
        self,
        x,
        y,
        z,
    ):

        axis_x = float(
            x
        )

        axis_y = float(
            z
        )

        axis_z = float(
            -y
        )

        length = (
            axis_x * axis_x
            + axis_y * axis_y
            + axis_z * axis_z
        )

        if length <= 1.0e-12:

            return (
                0.0,
                0.0,
                1.0,
            )

        length = (
            length ** 0.5
        )

        return (
            axis_x / length,
            axis_y / length,
            axis_z / length,
        )

    # =========================================================================
    # PIVOT
    # =========================================================================

    def _get_pivot(
        self,
        bone,
        scene,
    ):

        bone_name = bone.get(
            "name",
            "",
        )

        # ---------------------------------------------------------------------
        # Find Armature Object.
        # ---------------------------------------------------------------------

        armature_object = (
            self._find_armature_object(
                bone_name
            )
        )

        if armature_object is None:

            print(
                "[export_Blender5_XP12] "
                f"Animation pivot: "
                f"bone={bone_name} "
                f"Armature object NOT FOUND"
            )

            return (
                0.0,
                0.0,
                0.0,
            )

        print(
            "[export_Blender5_XP12] "
            f"Animation pivot armature: "
            f"bone={bone_name} "
            f"object={armature_object.name}"
        )

        # ---------------------------------------------------------------------
        # Actual Blender bone.
        # ---------------------------------------------------------------------

        blender_bone = (
            armature_object.data.bones.get(
                bone_name
            )
        )

        if blender_bone is None:

            print(
                "[export_Blender5_XP12] "
                f"Animation pivot: "
                f"bone={bone_name} "
                f"Blender bone NOT FOUND"
            )

            return (
                0.0,
                0.0,
                0.0,
            )

        # ---------------------------------------------------------------------
        # Bone head in Armature local coordinates.
        # ---------------------------------------------------------------------

        head_local = (
            blender_bone.head_local
        )

        # ---------------------------------------------------------------------
        # Armature local -> World.
        #
        # This is the actual position of the bone head in Blender world
        # coordinates.
        # ---------------------------------------------------------------------

        head_world = (
            armature_object.matrix_world
            @ head_local
        )

        # ---------------------------------------------------------------------
        # Blender World -> X-Plane World.
        #
        # THIS IS THE CRITICAL FIX.
        #
        # mesh_builder.py does exactly the same transformation for every VT:
        #
        #     x = co.x
        #     y = co.z
        #     z = -co.y
        #
        # Therefore pivot must use exactly the same transformation.
        #
        # Do NOT apply mesh_object.matrix_world.inverted().
        # ---------------------------------------------------------------------

        pivot_x = float(
            head_world.x
        )

        pivot_y = float(
            head_world.z
        )

        pivot_z = float(
            -head_world.y
        )

        print(
            "[export_Blender5_XP12] "
            f"Pivot transform: "
            f"bone={bone_name} "
            f"head_local=("
            f"{head_local.x:.6f}, "
            f"{head_local.y:.6f}, "
            f"{head_local.z:.6f}) "
            f"head_world=("
            f"{head_world.x:.6f}, "
            f"{head_world.y:.6f}, "
            f"{head_world.z:.6f}) "
            f"pivot_xplane=("
            f"{pivot_x:.6f}, "
            f"{pivot_y:.6f}, "
            f"{pivot_z:.6f})"
        )

        return (
            pivot_x,
            pivot_y,
            pivot_z,
        )

    # =========================================================================
    # FIND ARMATURE OBJECT
    # =========================================================================

    def _find_armature_object(
        self,
        bone_name,
    ):

        import bpy

        # ---------------------------------------------------------------------
        # Current Blender scene.
        # ---------------------------------------------------------------------

        for obj in bpy.context.scene.objects:

            if obj.type != "ARMATURE":
                continue

            if obj.data is None:
                continue

            if obj.data.bones.get(
                bone_name
            ) is not None:

                return obj

        # ---------------------------------------------------------------------
        # Fallback: all Blender objects.
        # ---------------------------------------------------------------------

        for obj in bpy.data.objects:

            if obj.type != "ARMATURE":
                continue

            if obj.data is None:
                continue

            if obj.data.bones.get(
                bone_name
            ) is not None:

                return obj

        return None
