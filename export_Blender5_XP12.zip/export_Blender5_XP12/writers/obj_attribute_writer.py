# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_attribute_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes OBJ8 drawing attributes.
#
# Назначение (RU):
#     Запись атрибутов отображения OBJ8.
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJAttributeWriter:

    """
    Writes OBJ8 attributes.
    """

    def write(
        self,
        file,
        scene,
    ):

        #
        # Default behaviour:
        #
        # X-Plane normally uses back-face culling.
        #
        # The scene can explicitly request no-cull.
        #

        file.write("\n")
