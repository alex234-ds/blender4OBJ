# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_header_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes OBJ header.
#
# Назначение (RU):
#     Запись заголовка OBJ.
# =============================================================================

from .obj_tokens import ALX_OBJTokens


class ALX_OBJHeaderWriter:

    """
    Writes the OBJ file header.
    """

    def write(
        self,
        file
    ):

        file.write(
            f"{ALX_OBJTokens.FILE_SIGNATURE}\n"
        )

        file.write(
            f"{ALX_OBJTokens.FILE_VERSION}\n"
        )

        file.write(
            f"{ALX_OBJTokens.FILE_TYPE}\n\n"
        )
