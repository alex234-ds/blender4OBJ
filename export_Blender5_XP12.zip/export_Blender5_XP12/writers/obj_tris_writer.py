# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_tris_writer.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Writes TRIS commands.
#
# Назначение (RU):
#     Запись команд TRIS.
# =============================================================================

from .obj_tokens import ALX_OBJTokens


from .obj_manip_writer import ALX_OBJManipWriter


class ALX_OBJTRISWriter:

    def write(
        self,
        file,
        scene,
    ):

        manip_writer = ALX_OBJManipWriter()

        #
        # TRIS references the index table.
        # offset - first index.
        # count  - number of indices (multiple of 3).
        #

        last_object = None

        for tris in scene.tris_table:

            obj = tris.get("object")
            if obj is not None and obj != last_object:
                manip_writer.write_for_object(file, obj)
                last_object = obj

            offset = int(
                tris["offset"]
            )

            count = int(
                tris["count"]
            )

            file.write(

                f"{ALX_OBJTokens.TRIS} "

                f"{offset} "

                f"{count}\n"

            )
