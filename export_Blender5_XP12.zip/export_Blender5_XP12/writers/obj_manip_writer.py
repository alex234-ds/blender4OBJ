# =============================================================================
# Project : export_Blender5_XP12
# File    : writers/obj_manip_writer.py
#
# Purpose:
#     Writes X-Plane OBJ8 manipulator attributes for a mesh object.
# =============================================================================


class ALX_OBJManipWriter:

    def write_for_object(self, file, obj):
        settings = getattr(obj, "alx_xplane_manip", None)
        if settings is None or not settings.enabled:
            return

        t = settings.type
        if t == "NONE":
            file.write("ATTR_manip_none\n")
            return

        cursor = settings.cursor
        tooltip = self._text(settings.tooltip)

        if t == "DRAG_AXIS":
            file.write(f"ATTR_manip_drag_axis {cursor} {settings.axis_x:.6f} {settings.axis_y:.6f} {settings.axis_z:.6f} {settings.v1min:.6f} {settings.v1max:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "DRAG_XY":
            file.write(f"ATTR_manip_drag_xy {cursor} {settings.dx:.6f} {settings.dy:.6f} {settings.v1min:.6f} {settings.v1max:.6f} {settings.v2min:.6f} {settings.v2max:.6f} {self._text(settings.dataref1)} {self._text(settings.dataref2)} {tooltip}\n")
        elif t == "COMMAND":
            file.write(f"ATTR_manip_command {cursor} {self._text(settings.command1)} {tooltip}\n")
        elif t == "COMMAND_AXIS":
            file.write(f"ATTR_manip_command_axis {cursor} {settings.axis_x:.6f} {settings.axis_y:.6f} {settings.axis_z:.6f} {self._text(settings.command1)} {self._text(settings.command2)} {tooltip}\n")
        elif t == "PUSH":
            file.write(f"ATTR_manip_push {cursor} {settings.v1:.6f} {settings.v2:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "RADIO":
            file.write(f"ATTR_manip_radio {cursor} {settings.v1:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "TOGGLE":
            file.write(f"ATTR_manip_toggle {cursor} {settings.v1:.6f} {settings.v2:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "DRAG_ROTATE":
            file.write(
                f"ATTR_manip_drag_rotate {cursor} "
                f"{settings.origin_x:.6f} {settings.origin_y:.6f} {settings.origin_z:.6f} "
                f"{settings.axis_x:.6f} {settings.axis_y:.6f} {settings.axis_z:.6f} "
                f"{settings.angle1:.6f} {settings.angle2:.6f} {settings.lift:.6f} "
                f"{settings.v1min:.6f} {settings.v1max:.6f} "
                f"{settings.v2min:.6f} {settings.v2max:.6f} "
                f"{self._text(settings.dataref1)} {self._text(settings.dataref2)} {tooltip}\n"
            )
        elif t == "COMMAND_KNOB":
            file.write(f"ATTR_manip_command_knob {cursor} {self._text(settings.command1)} {self._text(settings.command2)} {tooltip}\n")
        elif t == "COMMAND_SWITCH_UP_DOWN":
            file.write(f"ATTR_manip_command_switch_up_down {cursor} {self._text(settings.command1)} {self._text(settings.command2)} {tooltip}\n")
        elif t == "COMMAND_SWITCH_LEFT_RIGHT":
            file.write(f"ATTR_manip_command_switch_left_right {cursor} {self._text(settings.command1)} {self._text(settings.command2)} {tooltip}\n")
        elif t == "AXIS_KNOB":
            file.write(f"ATTR_manip_axis_knob {cursor} {settings.v1min:.6f} {settings.v1max:.6f} {settings.click_delta:.6f} {settings.hold_delta:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "AXIS_SWITCH_UP_DOWN":
            file.write(f"ATTR_manip_axis_switch_up_down {cursor} {settings.v1min:.6f} {settings.v1max:.6f} {settings.click_delta:.6f} {settings.hold_delta:.6f} {self._text(settings.dataref1)} {tooltip}\n")
        elif t == "AXIS_SWITCH_LEFT_RIGHT":
            file.write(f"ATTR_manip_axis_switch_left_right {cursor} {settings.v1min:.6f} {settings.v1max:.6f} {settings.click_delta:.6f} {settings.hold_delta:.6f} {self._text(settings.dataref1)} {tooltip}\n")

    @staticmethod
    def _text(value):
        return str(value or "").replace("\n", " ").strip()
