# =============================================================================
# Project : export_Blender5_XP12
# File    : operators/export_operator.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Export operator.
#
# Назначение (RU):
#     Оператор экспорта OBJ.
# =============================================================================

from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.io_utils import ExportHelper

from ..core.exporter import ALX_Exporter
from ..utils.collection_utils import get_collection_by_name


class ALX_OT_Export(
    Operator,
    ExportHelper,
):

    """
    Export X-Plane OBJ12.
    """

    bl_idname = "export_scene.xplane_obj12"
    bl_label = "Export X-Plane OBJ12"

    filename_ext = ".obj"

    filter_glob: StringProperty(
        default="*.obj",
        options={'HIDDEN'},
    )

    # =========================================================================
    # INVOKE
    # =========================================================================

    def invoke(
        self,
        context,
        event,
    ):

        settings = (
            context.scene.alx_export_settings
        )

        collection = get_collection_by_name(
            settings.export_collection
        )

        if collection is None:

            self.report(
                {'ERROR'},
                "Please select a collection."
            )

            return {'CANCELLED'}

        #
        # Use the selected collection name
        # as the default OBJ filename.
        #

        self.filepath = (
            collection.name
            + self.filename_ext
        )

        #
        # Open Blender file browser.
        #

        context.window_manager.fileselect_add(
            self
        )

        return {'RUNNING_MODAL'}

    # =========================================================================
    # EXECUTE
    # =========================================================================

    def execute(
        self,
        context,
    ):

        settings = (
            context.scene.alx_export_settings
        )

        collection = get_collection_by_name(
            settings.export_collection
        )

        if collection is None:

            self.report(
                {'ERROR'},
                "Please select a collection."
            )

            return {'CANCELLED'}

        exporter = ALX_Exporter(
            context=context,
            filepath=self.filepath,
            collection=collection,
            log_enabled=settings.log_enabled,
        )

        result = exporter.run()

        validation = result["validation"]

        for message in validation.errors:

            self.report(
                {'ERROR'},
                message
            )

        for message in validation.warnings:

            self.report(
                {'WARNING'},
                message
            )

        for message in validation.infos:

            self.report(
                {'INFO'},
                message
            )

        return result["status"]
