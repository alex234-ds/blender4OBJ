# =============================================================================
#
# Project : export_Blender5_XP12
# File    : __init__.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
# =============================================================================

bl_info = {
    "name": "X-Plane OBJ12 Exporter from Blender 5.X",
    "author": "Alex234 Design Studio",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "File > Export",
    "description": "Export X-Plane 12 OBJ from Blender 5.X",
    "category": "Import-Export",
}

import bpy

from bpy.props import PointerProperty

from .operators.export_operator import ALX_OT_Export
from .ui.export_panel import ALX_PT_Export

from .ui.properties import (
    ALX_PG_ExportSettings,
    ALX_PG_ObjectXPlaneManipulator,
    ALX_PG_XPlaneLight,
    ALX_PG_XPlaneMaterial,
    ALX_PG_BoneXPlaneKey,
    ALX_PG_BoneXPlane,
)

from .ui.object_xplane import (
    ALX_OT_ObjectXPlaneManipulatorInfo,
    ALX_OT_ObjectXPlaneManipulatorReset,
    ALX_OT_ObjectXPlaneManipulatorUseBoneAxis,
    ALX_PT_ObjectXPlaneManipulator,
)

from .ui.material_xplane import (
    ALX_PT_XPlaneMaterial,
)

from .ui.xplane_light import (
    ALX_OT_XPlaneLightInfo,
    ALX_PT_XPlaneLight,
)

from .ui.bone_xplane import (
    ALX_OT_BoneXPlaneAuto,
    ALX_OT_BoneXPlaneAddKey,
    ALX_OT_BoneXPlaneRemoveKey,
    ALX_OT_BoneXPlaneClear,
    ALX_PT_BoneXPlane,
)


def menu_func_export(self, context):

    self.layout.operator(
        ALX_OT_Export.bl_idname,
        text="X-Plane OBJ12 (.obj)",
    )


# Property groups MUST be registered before the panel/operators that use them.
classes = (
    ALX_PG_BoneXPlaneKey,
    ALX_PG_BoneXPlane,
    ALX_PG_ExportSettings,
    ALX_PG_ObjectXPlaneManipulator,
    ALX_PG_XPlaneLight,
    ALX_PG_XPlaneMaterial,

    ALX_OT_BoneXPlaneAuto,
    ALX_OT_BoneXPlaneAddKey,
    ALX_OT_BoneXPlaneRemoveKey,
    ALX_OT_BoneXPlaneClear,
    ALX_PT_BoneXPlane,

    ALX_PT_XPlaneMaterial,

    ALX_OT_ObjectXPlaneManipulatorInfo,
    ALX_OT_ObjectXPlaneManipulatorReset,
    ALX_OT_ObjectXPlaneManipulatorUseBoneAxis,
    ALX_PT_ObjectXPlaneManipulator,

    ALX_OT_XPlaneLightInfo,
    ALX_PT_XPlaneLight,

    ALX_PT_Export,
    ALX_OT_Export,
)


def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.alx_export_settings = PointerProperty(
        type=ALX_PG_ExportSettings,
    )

    bpy.types.Bone.alx_xplane = PointerProperty(
        type=ALX_PG_BoneXPlane,
    )

    bpy.types.Object.alx_xplane_manip = PointerProperty(
        type=ALX_PG_ObjectXPlaneManipulator,
    )

    bpy.types.Object.alx_xplane_light = PointerProperty(
        type=ALX_PG_XPlaneLight,
    )

    bpy.types.Material.alx_xplane_material = PointerProperty(
        type=ALX_PG_XPlaneMaterial,
    )

    bpy.types.TOPBAR_MT_file_export.append(
        menu_func_export,
    )


def unregister():

    bpy.types.TOPBAR_MT_file_export.remove(
        menu_func_export,
    )

    if hasattr(bpy.types.Bone, "alx_xplane"):
        del bpy.types.Bone.alx_xplane

    if hasattr(bpy.types.Object, "alx_xplane_manip"):
        del bpy.types.Object.alx_xplane_manip

    if hasattr(bpy.types.Object, "alx_xplane_light"):
        del bpy.types.Object.alx_xplane_light

    del bpy.types.Material.alx_xplane_material

    if hasattr(bpy.types.Scene, "alx_export_settings"):
        del bpy.types.Scene.alx_export_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
