# =============================================================================
# Project : export_Blender5_XP12
# File    : collectors/mesh_collector.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Collect mesh geometry without baking the current Armature pose into OBJ.
#
# Назначение (RU):
#     Сбор геометрии без запекания текущей позы Armature в OBJ.
# =============================================================================

import bpy


class ALX_MeshCollector:

    def collect(
        self,
        obj,
    ):

        depsgraph = (
            bpy.context.evaluated_depsgraph_get()
        )

        #
        # X-Plane performs bone animation itself with ANIM_rotate.
        #
        # Therefore two things must be kept separate:
        #
        #   1. mesh geometry must be exported in Blender REST/zero pose;
        #   2. ANIM_rotate must be the only source of bone rotation in PM.
        #
        # The previous implementation tried to reconstruct the REST transform
        # manually in mesh_builder.py. That is unsafe for Blender bone
        # parenting because matrix_parent_inverse, matrix_basis, bone roll and
        # parent transforms all participate in the final object transform.
        #
        # Blender can calculate this correctly for us: temporarily switch the
        # Armature data to REST pose, obtain the evaluated object's world matrix,
        # and then immediately restore the original pose mode.
        #

        export_world_matrix = obj.matrix_world.copy()

        armature_modifiers = []

        for modifier in obj.modifiers:

            if (
                modifier.type == "ARMATURE"
                and modifier.show_viewport
            ):

                armature_modifiers.append(modifier)
                modifier.show_viewport = False

        armature = None

        if (
            obj.parent is not None
            and obj.parent.type == "ARMATURE"
            and obj.parent_type in {
                "BONE",
                "BONE_RELATIVE",
            }
        ):

            armature = obj.parent

        original_pose_position = None

        if armature is not None:

            original_pose_position = (
                armature.data.pose_position
            )

            armature.data.pose_position = "REST"

            #
            # Force Blender to recalculate the dependency graph before asking
            # for matrix_world. This is important when the export is started
            # while the timeline is on an animated frame.
            #

            depsgraph.update()

            export_world_matrix = (
                obj.matrix_world.copy()
            )

        try:

            #
            # Obtain the mesh with Armature modifiers disabled. The mesh must
            # remain in its undeformed/rest geometry because X-Plane will
            # animate it later.
            #

            obj_eval = obj.evaluated_get(
                depsgraph
            )

            mesh = obj_eval.to_mesh()

        finally:

            #
            # Restore Blender exactly to the state in which the export began.
            #

            if armature is not None:

                armature.data.pose_position = (
                    original_pose_position
                )

                depsgraph.update()

            for modifier in armature_modifiers:

                modifier.show_viewport = True

        mesh.calc_loop_triangles()

        mesh_data = {

            "object": obj,

            "mesh": mesh,

            "vertices": mesh.vertices,

            "loops": mesh.loops,

            "loop_triangles": mesh.loop_triangles,

            "polygons": mesh.polygons,

            "uv_layer": (
                mesh.uv_layers.active.data
                if mesh.uv_layers.active
                else None
            ),

            "evaluated_object": obj_eval,

            "depsgraph": depsgraph,

            #
            # IMPORTANT:
            # This matrix is the actual Blender world matrix of the object in
            # REST pose. mesh_builder.py must use it instead of reconstructing
            # bone parenting by hand.
            #

            "export_world_matrix": export_world_matrix,

        }

        return mesh_data
