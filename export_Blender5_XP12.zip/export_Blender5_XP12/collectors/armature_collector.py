# =============================================================================
# Project : export_Blender5_XP12
# File    : collectors/armature_collector.py
#
# Company : Alex234 Design Studio
#
# Purpose (EN):
#     Collect armatures, bones, rotation axes and bone animation.
#
# Назначение (RU):
#     Сбор арматур, костей, осей вращения и анимации костей.
#
# Blender : 5.1+
# =============================================================================

import math

from mathutils import Euler, Quaternion

from bpy_extras import anim_utils


class ALX_ArmatureCollector:

    # =========================================================================
    # COLLECT
    # =========================================================================

    def collect(
        self,
        obj,
        respect_xplane=True,
    ):

        armature = obj.data

        bones = []

        for bone in armature.bones:

            # -----------------------------------------------------------------
            # Bone rotation axis.
            #
            # The axis is stored in ARMATURE SPACE.
            # -----------------------------------------------------------------

            axis = (
                bone.tail_local
                - bone.head_local
            )

            if axis.length > 0.0:

                axis.normalize()

            else:

                axis.x = 0.0
                axis.y = 0.0
                axis.z = 1.0

            bone_data = {

                "name": bone.name,

                "parent": (
                    bone.parent.name
                    if bone.parent is not None
                    else None
                ),

                "head": {

                    "x": bone.head_local.x,
                    "y": bone.head_local.y,
                    "z": bone.head_local.z,

                },

                "tail": {

                    "x": bone.tail_local.x,
                    "y": bone.tail_local.y,
                    "z": bone.tail_local.z,

                },

                "axis": {

                    "x": axis.x,
                    "y": axis.y,
                    "z": axis.z,

                },

                "rotation": {

                    "x": 0.0,
                    "y": 0.0,
                    "z": 0.0,

                },

                "rotation_mode": "XYZ",

                "animation": [],

                # Keep the rest-bone matrix.
                #
                # It is needed because Blender pose rotations are expressed
                # in the bone's local coordinate system, while the X-Plane
                # rotation axis is stored in armature coordinates.
                #
                "bone_matrix_local": bone.matrix_local.copy(),

            }

            pose_bone = obj.pose.bones.get(
                bone.name
            )

            if pose_bone is not None:

                bone_data["rotation_mode"] = (
                    pose_bone.rotation_mode
                )

            bones.append(
                bone_data
            )

        #
        # Collect bone animation.
        #

        self._collect_animation(
            obj,
            bones,
        )

        if respect_xplane:

            self._apply_xplane_settings(
                obj,
                bones,
            )

        return {

            "object": obj,

            "armature": armature,

            "bones": bones,

        }

    # =========================================================================
    # X-PLANE BONE SETTINGS
    # =========================================================================

    def _apply_xplane_settings(
        self,
        obj,
        bones,
    ):

        for bone_data in bones:

            blender_bone = obj.data.bones.get(
                bone_data["name"]
            )

            if blender_bone is None:

                bone_data["animation"] = []
                bone_data["dataref"] = ""

                continue

            settings = getattr(
                blender_bone,
                "alx_xplane",
                None,
            )

            if settings is None:

                bone_data["animation"] = []
                bone_data["dataref"] = ""

                continue

            dataref = str(
                getattr(
                    settings,
                    "dataref_name",
                    "",
                )
            ).strip()

            enabled = bool(
                getattr(
                    settings,
                    "animation_enabled",
                    False,
                )
            )

            bone_data["dataref"] = dataref

            #
            # Empty dataref is always equivalent to disabled.
            #

            if not enabled or not dataref:

                bone_data["animation"] = []

                continue

            table = getattr(
                settings,
                "keyframes",
                None,
            )

            if table is None or len(table) == 0:

                bone_data["animation"] = []

                continue

            animation = []

            for item in table:

                animation.append({

                    "frame": float(
                        item.frame
                    ),

                    "dataref_value": float(
                        item.dataref_value
                    ),

                    "bone_angle": float(
                        item.bone_angle
                    ),

                })

            animation.sort(
                key=lambda item: item["frame"]
            )

            bone_data["animation"] = animation

            print(
                "[export_Blender5_XP12] "
                f"X-Plane animation: "
                f"bone={bone_data['name']} "
                f"dataref={dataref} "
                f"keys={len(animation)}"
            )

    # =========================================================================
    # ANIMATION
    # =========================================================================

    def _collect_animation(
        self,
        obj,
        bones,
    ):

        print(
            "[export_Blender5_XP12] "
            f"Animation data check: "
            f"object={obj.name}"
        )

        animation_data = (
            obj.animation_data
        )

        if animation_data is None:

            print(
                "[export_Blender5_XP12] "
                "  animation_data: NONE"
            )

            return

        print(
            "[export_Blender5_XP12] "
            "  animation_data: OK"
        )

        action = (
            animation_data.action
        )

        if action is None:

            print(
                "[export_Blender5_XP12] "
                "  action: NONE"
            )

            return

        print(
            "[export_Blender5_XP12] "
            f"  action: {action.name}"
        )

        bones_by_name = {

            bone["name"]: bone

            for bone in bones

        }

        # ---------------------------------------------------------------------
        # Blender 5.x animation system.
        #
        # Action
        #   -> Layers
        #      -> Strips
        #         -> ChannelBags
        #            -> F-Curves
        # ---------------------------------------------------------------------

        channelbags = []

        action_slot = (
            animation_data.action_slot
        )

        if action_slot is not None:

            print(
                "[export_Blender5_XP12] "
                f"  action_slot: "
                f"{action_slot}"
            )

            channelbag = (
                anim_utils.action_get_channelbag_for_slot(
                    action,
                    action_slot,
                )
            )

            if channelbag is not None:

                print(
                    "[export_Blender5_XP12] "
                    f"  channelbag: OK "
                    f"fcurves={len(channelbag.fcurves)}"
                )

                channelbags.append(
                    channelbag
                )

            else:

                print(
                    "[export_Blender5_XP12] "
                    "  channelbag: NONE"
                )

        else:

            print(
                "[export_Blender5_XP12] "
                "  action_slot: NONE"
            )

        # ---------------------------------------------------------------------
        # Fallback.
        # ---------------------------------------------------------------------

        if not channelbags:

            print(
                "[export_Blender5_XP12] "
                "  Searching action layers..."
            )

            for layer in action.layers:

                print(
                    "[export_Blender5_XP12] "
                    f"    Layer: {layer.name}"
                )

                for strip in layer.strips:

                    print(
                        "[export_Blender5_XP12] "
                        f"      Strip: "
                        f"{strip.name}"
                    )

                    for channelbag in strip.channelbags:

                        print(
                            "[export_Blender5_XP12] "
                            f"        ChannelBag: "
                            f"fcurves={len(channelbag.fcurves)}"
                        )

                        if (
                            action_slot is not None
                            and channelbag.slot != action_slot
                        ):

                            continue

                        channelbags.append(
                            channelbag
                        )

        if not channelbags:

            print(
                "[export_Blender5_XP12] "
                "  Animation channels: NONE"
            )

            return

        # ---------------------------------------------------------------------
        # Collect rotation channels.
        # ---------------------------------------------------------------------

        channels = {}

        for channelbag in channelbags:

            for fcurve in channelbag.fcurves:

                data_path = (
                    fcurve.data_path
                )

                print(
                    "[export_Blender5_XP12] "
                    f"  FCurve: "
                    f"path={data_path} "
                    f"index={fcurve.array_index} "
                    f"keys={len(fcurve.keyframe_points)}"
                )

                bone_name = (
                    self._get_bone_name(
                        data_path
                    )
                )

                if bone_name is None:

                    print(
                        "[export_Blender5_XP12] "
                        "    -> not a pose bone"
                    )

                    continue

                bone_data = (
                    bones_by_name.get(
                        bone_name
                    )
                )

                if bone_data is None:

                    print(
                        "[export_Blender5_XP12] "
                        f"    -> bone not found: "
                        f"{bone_name}"
                    )

                    continue

                channel = (
                    self._get_rotation_channel(
                        data_path
                    )
                )

                if channel is None:

                    print(
                        "[export_Blender5_XP12] "
                        "    -> not rotation channel"
                    )

                    continue

                print(
                    "[export_Blender5_XP12] "
                    f"    -> bone={bone_name} "
                    f"channel={channel}"
                )

                key = (
                    bone_name,
                    channel,
                    fcurve.array_index,
                )

                values = []

                for keyframe in fcurve.keyframe_points:

                    values.append({

                        "frame": float(
                            keyframe.co.x
                        ),

                        "value": float(
                            keyframe.co.y
                        ),

                    })

                channels[key] = values

        # ---------------------------------------------------------------------
        # Group channels by bone.
        # ---------------------------------------------------------------------

        bone_channels = {}

        for (
            bone_name,
            channel,
            array_index,
        ), values in channels.items():

            bone_channels.setdefault(
                bone_name,
                []
            ).append({

                "channel": channel,

                "array_index": array_index,

                "keys": values,

            })

        # ---------------------------------------------------------------------
        # Build axis-angle animation.
        # ---------------------------------------------------------------------

        for bone_name, animation_channels in bone_channels.items():

            bone_data = (
                bones_by_name[
                    bone_name
                ]
            )

            animation = (
                self._build_axis_animation(
                    bone_data,
                    animation_channels,
                )
            )

            bone_data["animation"] = animation

            print(
                "[export_Blender5_XP12] "
                f"Animation collected: "
                f"bone={bone_name} "
                f"axis-keys={len(animation)}"
            )

        # ---------------------------------------------------------------------
        # Preserve legacy rotation field.
        # ---------------------------------------------------------------------

        for bone_data in bones:

            self._set_initial_rotation(
                bone_data
            )

    # =========================================================================
    # BUILD AXIS ANIMATION
    # =========================================================================

    def _build_axis_animation(
        self,
        bone_data,
        channels,
    ):

        frames = set()

        for channel_data in channels:

            for key in channel_data["keys"]:

                frames.add(
                    float(
                        key["frame"]
                    )
                )

        if not frames:

            return []

        frames = sorted(
            frames
        )

        rotation_mode = bone_data.get(
            "rotation_mode",
            "XYZ",
        )

        # ---------------------------------------------------------------------
        # Axis is stored in ARMATURE SPACE.
        # ---------------------------------------------------------------------

        axis_data = bone_data["axis"]

        axis_armature = (
            float(axis_data["x"]),
            float(axis_data["y"]),
            float(axis_data["z"]),
        )

        axis_length = math.sqrt(

            axis_armature[0] * axis_armature[0]
            + axis_armature[1] * axis_armature[1]
            + axis_armature[2] * axis_armature[2]

        )

        if axis_length <= 1.0e-12:

            axis_armature = (
                0.0,
                0.0,
                1.0,
            )

        else:

            axis_armature = (

                axis_armature[0] / axis_length,
                axis_armature[1] / axis_length,
                axis_armature[2] / axis_length,

            )

        # ---------------------------------------------------------------------
        # IMPORTANT:
        #
        # Pose rotation quaternion is expressed in the bone's LOCAL
        # coordinate system.
        #
        # The X-Plane axis is expressed in ARMATURE coordinates.
        #
        # Convert the axis to bone-local coordinates before extracting
        # the twist angle.
        # ---------------------------------------------------------------------

        bone_matrix_local = (
            bone_data.get(
                "bone_matrix_local",
                None,
            )
        )

        if bone_matrix_local is not None:

            try:

                inverse_basis = (
                    bone_matrix_local.to_3x3().inverted()
                )

                axis_local_vector = (
                    inverse_basis @ axis_armature
                )

                if axis_local_vector.length > 1.0e-12:

                    axis_local_vector.normalize()

                    axis_local = (

                        float(axis_local_vector.x),
                        float(axis_local_vector.y),
                        float(axis_local_vector.z),

                    )

                else:

                    axis_local = (
                        0.0,
                        1.0,
                        0.0,
                    )

            except Exception:

                axis_local = (
                    0.0,
                    1.0,
                    0.0,
                )

        else:

            axis_local = (
                0.0,
                1.0,
                0.0,
            )

        print(
            "[export_Blender5_XP12] "
            f"  Axis conversion: "
            f"bone={bone_data['name']} "
            f"armature_axis=("
            f"{axis_armature[0]:.6f}, "
            f"{axis_armature[1]:.6f}, "
            f"{axis_armature[2]:.6f}) "
            f"local_axis=("
            f"{axis_local[0]:.6f}, "
            f"{axis_local[1]:.6f}, "
            f"{axis_local[2]:.6f})"
        )

        result = []

        previous_angle = None

        for frame in frames:

            quaternion = (
                self._rotation_quaternion_at_frame(
                    channels,
                    frame,
                    rotation_mode,
                )
            )

            angle = (
                self._signed_axis_angle(
                    quaternion,
                    axis_local,
                )
            )

            # -----------------------------------------------------------------
            # Unwrap angle so crossing +/-180 degrees does not introduce a
            # false 360-degree jump.
            # -----------------------------------------------------------------

            if previous_angle is not None:

                while (
                    angle - previous_angle
                    > 180.0
                ):

                    angle -= 360.0

                while (
                    angle - previous_angle
                    < -180.0
                ):

                    angle += 360.0

            previous_angle = angle

            result.append({

                "frame": float(
                    frame
                ),

                "angle": float(
                    angle
                ),

            })

            print(
                "[export_Blender5_XP12] "
                f"  Axis animation: "
                f"bone={bone_data['name']} "
                f"frame={frame:.6f} "
                f"angle_deg={angle:.6f}"
            )

        return result

    # =========================================================================
    # ROTATION QUATERNION AT FRAME
    # =========================================================================

    def _rotation_quaternion_at_frame(
        self,
        channels,
        frame,
        rotation_mode,
    ):

        # ---------------------------------------------------------------------
        # Euler.
        # ---------------------------------------------------------------------

        euler_channels = [
            None,
            None,
            None,
        ]

        for channel_data in channels:

            if (
                channel_data["channel"]
                != "rotation_euler"
            ):

                continue

            index = (
                channel_data["array_index"]
            )

            if 0 <= index < 3:

                euler_channels[index] = (
                    channel_data["keys"]
                )

        if any(
            keys is not None
            for keys in euler_channels
        ):

            values = [

                self._value_at_frame(
                    keys,
                    frame,
                )
                if keys is not None
                else 0.0

                for keys in euler_channels

            ]

            if rotation_mode in {
                "QUATERNION",
                "AXIS_ANGLE",
            }:

                rotation_mode = "XYZ"

            try:

                euler = Euler(
                    values,
                    rotation_mode,
                )

            except ValueError:

                euler = Euler(
                    values,
                    "XYZ",
                )

            return euler.to_quaternion()

        # ---------------------------------------------------------------------
        # Quaternion.
        # ---------------------------------------------------------------------

        quaternion_channels = [
            None,
            None,
            None,
            None,
        ]

        for channel_data in channels:

            if (
                channel_data["channel"]
                != "rotation_quaternion"
            ):

                continue

            index = (
                channel_data["array_index"]
            )

            if 0 <= index < 4:

                quaternion_channels[index] = (
                    channel_data["keys"]
                )

        if any(
            keys is not None
            for keys in quaternion_channels
        ):

            values = [

                self._value_at_frame(
                    keys,
                    frame,
                )
                if keys is not None
                else (
                    1.0
                    if index == 0
                    else 0.0
                )

                for index, keys
                in enumerate(
                    quaternion_channels
                )

            ]

            quaternion = Quaternion(
                values
            )

            quaternion.normalize()

            return quaternion

        return Quaternion()

    # =========================================================================
    # SIGNED AXIS ANGLE
    # =========================================================================

    def _signed_axis_angle(
        self,
        quaternion,
        axis,
    ):

        # ---------------------------------------------------------------------
        # Normalize quaternion.
        # ---------------------------------------------------------------------

        q = quaternion.copy()

        q.normalize()

        # ---------------------------------------------------------------------
        # Normalize axis.
        # ---------------------------------------------------------------------

        axis_length = math.sqrt(

            axis[0] * axis[0]
            + axis[1] * axis[1]
            + axis[2] * axis[2]

        )

        if axis_length <= 1.0e-12:

            axis = (
                0.0,
                1.0,
                0.0,
            )

        else:

            axis = (

                axis[0] / axis_length,
                axis[1] / axis_length,
                axis[2] / axis_length,

            )

        # ---------------------------------------------------------------------
        # Swing-twist decomposition.
        #
        # The twist quaternion contains only the rotation around the
        # requested LOCAL bone axis.
        # ---------------------------------------------------------------------

        vector = (
            q.x,
            q.y,
            q.z,
        )

        projection = (

            vector[0] * axis[0]
            + vector[1] * axis[1]
            + vector[2] * axis[2]

        )

        twist = Quaternion((

            q.w,

            axis[0] * projection,
            axis[1] * projection,
            axis[2] * projection,

        ))

        twist_length = math.sqrt(

            twist.w * twist.w
            + twist.x * twist.x
            + twist.y * twist.y
            + twist.z * twist.z

        )

        if twist_length <= 1.0e-12:

            return 0.0

        twist.normalize()

        # ---------------------------------------------------------------------
        # Convert twist quaternion to signed angle.
        # ---------------------------------------------------------------------

        angle = 2.0 * math.atan2(

            projection,
            twist.w,

        )

        # ---------------------------------------------------------------------
        # Normalize to [-pi, pi].
        # ---------------------------------------------------------------------

        while angle > math.pi:

            angle -= (
                2.0 * math.pi
            )

        while angle < -math.pi:

            angle += (
                2.0 * math.pi
            )

        return math.degrees(
            angle
        )

    # =========================================================================
    # BONE NAME
    # =========================================================================

    def _get_bone_name(
        self,
        data_path,
    ):

        prefix = (
            'pose.bones["'
        )

        if not data_path.startswith(
            prefix
        ):

            return None

        start = len(
            prefix
        )

        end = data_path.find(
            '"]',
            start,
        )

        if end < 0:

            return None

        return data_path[
            start:end
        ]

    # =========================================================================
    # ROTATION CHANNEL
    # =========================================================================

    def _get_rotation_channel(
        self,
        data_path,
    ):

        if data_path.endswith(
            ".rotation_euler"
        ):

            return "rotation_euler"

        if data_path.endswith(
            ".rotation_quaternion"
        ):

            return "rotation_quaternion"

        return None

    # =========================================================================
    # INITIAL ROTATION
    # =========================================================================

    def _set_initial_rotation(
        self,
        bone_data,
    ):

        animation = (
            bone_data.get(
                "animation",
                [],
            )
        )

        if not animation:

            return

        first = animation[0]

        angle = float(
            first.get(
                "angle",
                0.0,
            )
        )

        #
        # Keep the old interface.
        #

        bone_data["rotation"] = {

            "x": 0.0,
            "y": 0.0,
            "z": angle,

        }

    # =========================================================================
    # VALUE AT FRAME
    # =========================================================================

    def _value_at_frame(
        self,
        keys,
        frame,
    ):

        if not keys:

            return 0.0

        for key in keys:

            if abs(
                key["frame"] - frame
            ) <= 1.0e-8:

                return key["value"]

        if frame <= keys[0]["frame"]:

            return keys[0]["value"]

        if frame >= keys[-1]["frame"]:

            return keys[-1]["value"]

        for index in range(
            len(keys) - 1
        ):

            left = keys[index]
            right = keys[index + 1]

            if (
                left["frame"]
                <= frame
                <= right["frame"]
            ):

                frame_a = left["frame"]
                frame_b = right["frame"]

                value_a = left["value"]
                value_b = right["value"]

                delta_frame = (
                    frame_b - frame_a
                )

                if abs(
                    delta_frame
                ) <= 1.0e-12:

                    return value_a

                factor = (
                    frame - frame_a
                ) / delta_frame

                return (
                    value_a
                    + (
                        value_b
                        - value_a
                    ) * factor
                )

        return keys[-1]["value"]
