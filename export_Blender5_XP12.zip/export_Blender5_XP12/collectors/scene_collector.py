# =============================================================================
# Project : export_Blender5_XP12
# File    : collectors/scene_collector.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Collect exportable Blender objects and build OBJ8 export groups.
#
# Назначение (RU):
#     Сбор экспортируемых объектов Blender и формирование групп OBJ8
#     по используемой текстуре.
# =============================================================================

from ..core.scene_data import ALX_SceneData
from .mesh_collector import ALX_MeshCollector
from .armature_collector import ALX_ArmatureCollector

from ..builders.mesh_builder import ALX_MeshBuilder
from ..builders.material_builder import ALX_MaterialBuilder


class ALX_SceneCollector:

    def __init__(
        self,
        collection,
    ):

        self.collection = collection

        self.mesh_collector = (
            ALX_MeshCollector()
        )

        self.armature_collector = (
            ALX_ArmatureCollector()
        )

        self.mesh_builder = (
            ALX_MeshBuilder()
        )

        self.material_builder = (
            ALX_MaterialBuilder()
        )

    # =========================================================================
    # COLLECT
    # =========================================================================

    def collect(
        self,
    ):

        scene = ALX_SceneData()

        scene.collection = (
            self.collection
        )

        objects = list(
            self.collection.all_objects
        )

        print(
            "[export_Blender5_XP12] "
            f"Collection: {self.collection.name}"
        )

        print(
            "[export_Blender5_XP12] "
            f"Objects found: {len(objects)}"
        )

        for obj in objects:

            print(
                "[export_Blender5_XP12] "
                f"Object: {obj.name} "
                f"Type: {obj.type}"
            )

            # =================================================================
            # MESH
            # =================================================================

            if obj.type == "MESH":

                scene.meshes.append(
                    obj
                )

                #
                # Determine material / texture.
                #

                texture = (
                    self._get_object_texture(
                        obj
                    )
                )

                glass = self._get_object_glass(obj)

                print(
                    "[export_Blender5_XP12] "
                    f"  Texture: "
                    f"{texture or '<none>'}"
                )

                #
                # Collect raw mesh.
                #

                mesh_data = (
                    self.mesh_collector.collect(
                        obj
                    )
                )

                scene.mesh_data.append(
                    mesh_data
                )

                #
                # Build local geometry.
                #

                built = (
                    self.mesh_builder.build(
                        mesh_data
                    )
                )

                local_vt = built[
                    "vt_table"
                ]

                local_idx = built[
                    "idx_table"
                ]

                local_tris = built[
                    "tris_table"
                ]

                #
                # Existing global tables.
                #

                vt_offset = len(
                    scene.vt_table
                )

                idx_offset = len(
                    scene.idx_table
                )

                #
                # Global VT.
                #

                scene.vt_table.extend(
                    local_vt
                )

                #
                # Global IDX.
                #

                for index in local_idx:

                    scene.idx_table.append(
                        index + vt_offset
                    )

                #
                # Global TRIS.
                #

                for tris in local_tris:

                    scene.tris_table.append({

                        "offset": (
                            tris["offset"]
                            + idx_offset
                        ),

                        "count": (
                            tris["count"]
                        ),

                        "object": obj,

                    })

                #
                # Add geometry to export group.
                #

                group = (
                    self._get_or_create_group(
                        scene,
                        texture,
                        glass,
                    )
                )

                group_vt_offset = len(
                    group["vt_table"]
                )

                group_idx_offset = len(
                    group["idx_table"]
                )

                #
                # Group VT.
                #

                group["vt_table"].extend(
                    local_vt
                )

                #
                # Group IDX.
                #

                for index in local_idx:

                    group["idx_table"].append(
                        index
                        + group_vt_offset
                    )

                #
                # Group TRIS.
                #

                for tris in local_tris:

                    group["tris_table"].append({

                        "offset": (
                            tris["offset"]
                            + group_idx_offset
                        ),

                        "count": (
                            tris["count"]
                        ),

                        "object": obj,

                    })

                #
                # Store object and mesh data.
                #

                group["objects"].append(
                    obj
                )

                group["mesh_data"].append(
                    mesh_data
                )

                # OBJ8 animation affects the geometry inside its ANIM scope.
                # Keep animation scoped to the groups that actually contain
                # geometry parented to the animated bone.
                bone_name = self._get_object_bone_name(obj)

                if bone_name:
                    if bone_name not in group["bone_names"]:
                        group["bone_names"].append(bone_name)

            # =================================================================
            # LIGHT
            # =================================================================

            elif obj.type == "LIGHT":

                scene.lights.append(
                    obj
                )

            # =================================================================
            # EMPTY
            # =================================================================

            elif obj.type == "EMPTY":

                scene.empties.append(
                    obj
                )

            # =================================================================
            # ARMATURE
            # =================================================================

            elif obj.type == "ARMATURE":

                scene.armatures.append(
                    obj
                )

                #
                # Collect armature data.
                #

                armature_data = (
                    self.armature_collector.collect(
                        obj
                    )
                )

                bones = (
                    armature_data.get(
                        "bones",
                        [],
                    )
                )

                #
                # Store all bones in the export scene.
                #

                scene.bones.extend(
                    bones
                )

                print(
                    "[export_Blender5_XP12] "
                    f"  Bones: {len(bones)}"
                )

                for bone in bones:

                    axis = bone.get(
                        "axis",
                        {},
                    )

                    print(
                        "[export_Blender5_XP12] "
                        f"    Bone: "
                        f"{bone.get('name', '')} "
                        f"axis=("
                        f"{axis.get('x', 0.0):.6f}, "
                        f"{axis.get('y', 0.0):.6f}, "
                        f"{axis.get('z', 1.0):.6f}"
                        f")"
                    )

            # =================================================================
            # UNKNOWN / OTHER
            # =================================================================

            else:

                continue

        #
        # Diagnostics.
        #

        print(
            "[export_Blender5_XP12] "
            f"Meshes collected: "
            f"{len(scene.meshes)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"Lights collected: "
            f"{len(scene.lights)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"Armatures collected: "
            f"{len(scene.armatures)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"Bones collected: "
            f"{len(scene.bones)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"VT records: "
            f"{len(scene.vt_table)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"IDX records: "
            f"{len(scene.idx_table)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"TRIS commands: "
            f"{len(scene.tris_table)}"
        )

        print(
            "[export_Blender5_XP12] "
            f"Export groups: "
            f"{len(scene.export_groups)}"
        )

        for group in scene.export_groups:

            print(
                "[export_Blender5_XP12] "
                f"  Group texture: "
                f"{group['texture'] or '<none>'} "
                f"objects={len(group['objects'])} "
                f"VT={len(group['vt_table'])} "
                f"IDX={len(group['idx_table'])} "
                f"TRIS={len(group['tris_table'])}"
            )

        return scene

    # =========================================================================
    # OBJECT TEXTURE
    # =========================================================================

    def _get_object_texture(
        self,
        obj,
    ):

        class TextureContainer:

            def __init__(self):

                self.materials = []

                self.texture = None

                self.texture_lit = None

                self.texture_normal = None

        container = (
            TextureContainer()
        )

        self.material_builder.build(
            obj,
            container,
        )

        return container.texture

    def _get_object_glass(
        self,
        obj,
    ):

        for slot in obj.material_slots:

            material = slot.material

            if material is None:
                continue

            settings = getattr(
                material,
                "alx_xplane_material",
                None,
            )

            if settings is not None:
                return bool(
                    getattr(settings, "glass", False)
                )

        return False

    def _get_object_bone_name(
        self,
        obj,
    ):

        parent = getattr(obj, "parent", None)

        if parent is None:
            return None

        if getattr(parent, "type", None) != "ARMATURE":
            return None

        parent_type = getattr(obj, "parent_type", "")

        if parent_type not in {
            "BONE",
            "BONE_RELATIVE",
        }:
            return None

        bone_name = str(
            getattr(obj, "parent_bone", "") or ""
        ).strip()

        return bone_name or None

    # =========================================================================
    # GROUP
    # =========================================================================

    def _get_or_create_group(
        self,
        scene,
        texture,
        glass=False,
    ):

        for group in scene.export_groups:

            if (
                group["texture"] == texture
                and group.get("glass", False) == bool(glass)
            ):

                return group

        group = {

            "texture": texture,

            "glass": bool(glass),

            "texture_lit": None,

            "texture_normal": None,


            "objects": [],

            "mesh_data": [],

            "bone_names": [],

            "vt_table": [],

            "idx_table": [],

            "tris_table": [],

        }

        scene.export_groups.append(
            group
        )

        return group
