# =============================================================================
# Project : export_Blender5_XP12
# File    : core/exporter.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
# Main export coordinator.
#
# Назначение (RU):
# Главный координатор процесса экспорта.
# =============================================================================

from pathlib import Path

from .log import ALX_Log
from .validator import ALX_Validator
from ..collectors.scene_collector import ALX_SceneCollector
from ..writers.obj_writer import ALX_OBJWriter


class ALX_Exporter:

    """
    Coordinates the complete export process.
    """

    def __init__(
        self,
        context,
        filepath,
        collection,
        log_enabled=False,
    ):

        self.context = context
        self.filepath = filepath
        self.collection = collection
        self.log_enabled = bool(log_enabled)

        self.log = ALX_Log()

    # =========================================================================
    # RUN
    # =========================================================================

    def run(
        self,
    ):

        self.log.info(
            "Export started."
        )

        #
        # Validation
        #

        validator = ALX_Validator(
            self.collection
        )

        validation = validator.validate()

        for message in validation.infos:

            self.log.info(
                message
            )

        for message in validation.warnings:

            self.log.warning(
                message
            )

        for message in validation.errors:

            self.log.error(
                message
            )

        if not validation.is_valid:

            self.__save_log()

            return {
                "status": {'CANCELLED'},
                "validation": validation,
            }

        #
        # Scene collection
        #

        self.log.info(
            "Collecting scene."
        )

        collector = ALX_SceneCollector(
            self.collection
        )

        scene = collector.collect()

        #
        # Apply export settings.
        #

        settings = self.context.scene.alx_export_settings
        self._apply_export_settings(
            scene,
            settings,
        )

        #
        # Validate collected export scene.
        #

        validator.validate_scene(
            scene
        )

        validation = validator.result

        for message in validation.warnings:

            self.log.warning(
                message
            )

        for message in validation.errors:

            self.log.error(
                message
            )

        if not validation.is_valid:

            self.__save_log()

            return {
                "status": {'CANCELLED'},
                "validation": validation,
            }

        self.log.info(
            "Export scene validation passed."
        )

        #
        # OBJ writing
        #

        self.log.info(
            "Writing OBJ."
        )

        writer = ALX_OBJWriter(
            self.filepath
        )

        writer.write(
            scene
        )

        validation.add_info(
            "OBJ file successfully written."
        )

        self.log.info(
            "Export finished successfully."
        )

        self.__save_log()

        return {
            "status": {'FINISHED'},
            "validation": validation,
        }


    # =========================================================================
    # EXPORT SETTINGS
    # =========================================================================

    @staticmethod
    def _apply_export_settings(
        scene,
        settings,
    ):

        add_normal = bool(
            getattr(settings, "texture_normal_enabled", False)
        )
        add_lit = bool(
            getattr(settings, "texture_lit_enabled", False)
        )

        for group in scene.export_groups:

            texture = str(
                group.get("texture") or ""
            ).strip()

            # Additional texture files are meaningful only when the main
            # texture exists. Their names are derived deterministically from
            # the main texture: Gears.png -> Gears_NRM.png / Gears_LIT.png.
            if not texture:
                group["texture_normal"] = None
                group["texture_lit"] = None
                continue

            path = Path(texture)
            stem = path.stem
            suffix = path.suffix

            def derived(name):
                filename = f"{stem}_{name}{suffix}" if suffix else f"{stem}_{name}"
                return str(path.with_name(filename)).replace("\\", "/")

            group["texture_normal"] = (
                derived("NRM") if add_normal else None
            )
            group["texture_lit"] = (
                derived("LIT") if add_lit else None
            )

    # =========================================================================
    # SAVE LOG
    # =========================================================================

    def __save_log(
        self,
    ):

        if not self.log_enabled:
            return

        log_path = Path(
            self.filepath
        ).with_suffix(
            ".log"
        )

        self.log.save(
            str(log_path)
        )
