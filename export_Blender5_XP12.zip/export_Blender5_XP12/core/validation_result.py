# =============================================================================
# Project : export_Blender5_XP12
# File    : core/validation_result.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Validation result container.
#
# Назначение (RU):
#     Контейнер результатов проверки.
# =============================================================================


class ALX_ValidationResult:
    """
    Stores validation messages.
    """

    def __init__(self):

        self.errors = []
        self.warnings = []
        self.infos = []


    def add_error(self, message):

        self.errors.append(message)


    def add_warning(self, message):

        self.warnings.append(message)


    def add_info(self, message):

        self.infos.append(message)


    @property
    def is_valid(self):

        return len(self.errors) == 0
