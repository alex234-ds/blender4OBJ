# =============================================================================
# Project : export_Blender5_XP12
# File    : core/scene_data.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
# =============================================================================


class ALX_SceneData:

    def __init__(self):

        #
        # Source collection
        #

        self.collection = None

        #
        # Blender objects
        #

        self.meshes = []

        self.lights = []

        self.armatures = []

        self.empties = []

        #
        # Bones
        #

        self.bones = []

        #
        # Raw Blender mesh data
        #

        self.mesh_data = []

        #
        # Materials
        #

        self.materials = []

        #
        # OBJ8 textures
        #

        self.texture = None

        self.texture_lit = None

        self.texture_normal = None

        #
        # OBJ8 attributes
        #
        # Default:
        #     back-face culling enabled.
        #


        #
        # OBJ8 geometry tables
        #

        self.vt_table = []

        self.idx_table = []

        self.tris_table = []

        #
        # Export groups.
        #
        # Each item contains:
        #
        # {
        #     "texture": "...",
        #     "texture_lit": "...",
        #     "texture_normal": "...",
        #     "objects": [...],
        #     "mesh_data": [...],
        #     "bone_names": [...],
        #     "vt_table": [...],
        #     "idx_table": [...],
        #     "tris_table": [...],
        # }
        #

        self.export_groups = []
