# =============================================================================
# Project : export_Blender5_XP12
# File    : core/log.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Export log writer.
#
# Назначение (RU):
#     Журналирование процесса экспорта.
# =============================================================================

from datetime import datetime


class ALX_Log:
    """
    Export log.
    """

    def __init__(self):

        self.messages = []


    def info(self, message):

        self.__add("INFO", message)


    def warning(self, message):

        self.__add("WARNING", message)


    def error(self, message):

        self.__add("ERROR", message)


    def __add(self, level, message):

        timestamp = datetime.now().strftime(
            "%H:%M:%S"
        )

        self.messages.append(
            f"[{timestamp}] {level:<7} {message}"
        )


    def save(self, filepath):

        with open(
            filepath,
            "w",
            encoding="utf-8"
        ) as file:

            file.write(
                "Alex234 Design Studio\n"
            )

            file.write(
                "X-Plane OBJ Export Log\n"
            )

            file.write(
                "=" * 72 + "\n\n"
            )

            for line in self.messages:

                file.write(
                    line + "\n"
                )
