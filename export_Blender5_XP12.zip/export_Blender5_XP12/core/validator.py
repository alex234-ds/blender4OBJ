# =============================================================================
#
# Project : export_Blender5_XP12
# File    : core/validator.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
# Validation of Blender data before export.
#
# Назначение (RU):
# Проверка данных Blender перед экспортом.
#
# =============================================================================

from .validation_result import ALX_ValidationResult


class ALX_Validator:
    """
    Validation of export data.
    """

    def __init__(
        self,
        collection,
    ):

        self.collection = collection

        self.result = (
            ALX_ValidationResult()
        )

    # =========================================================================
    # VALIDATE
    # =========================================================================

    def validate(
        self,
    ):

        self.result = (
            ALX_ValidationResult()
        )

        self.__validate_collection()

        self.__validate_mesh_objects()

        self.__validate_mesh_geometry()

        self.__validate_uv_layers()

        self.result.add_info(
            f'Collection "{self.collection.name}" checked.'
        )

        return self.result

    # =========================================================================
    # COLLECTION
    # =========================================================================

    def __validate_collection(
        self,
    ):

        if self.collection is None:

            self.result.add_error(
                "Collection is not defined."
            )

            return

        if not self.collection.name:

            self.result.add_error(
                "Collection has no name."
            )

    # =========================================================================
    # MESH OBJECTS
    # =========================================================================

    def __validate_mesh_objects(
        self,
    ):

        mesh_count = 0

        for obj in self.collection.objects:

            if obj.type == 'MESH':

                mesh_count += 1

        if mesh_count == 0:

            self.result.add_error(
                "Collection does not contain "
                "any mesh objects."
            )

            return

        self.result.add_info(
            f"Mesh objects found: {mesh_count}"
        )

    # =========================================================================
    # MESH GEOMETRY
    # =========================================================================

    def __validate_mesh_geometry(
        self,
    ):

        for obj in self.collection.objects:

            if obj.type != 'MESH':
                continue

            mesh = obj.data

            if mesh is None:

                self.result.add_error(
                    f'Object "{obj.name}" '
                    f'has no mesh data.'
                )

                continue

            vertex_count = len(
                mesh.vertices
            )

            polygon_count = len(
                mesh.polygons
            )

            loop_count = len(
                mesh.loops
            )

            if vertex_count == 0:

                self.result.add_warning(
                    f'Object "{obj.name}" '
                    f'contains no vertices.'
                )

            if polygon_count == 0:

                self.result.add_warning(
                    f'Object "{obj.name}" '
                    f'contains no polygons.'
                )

            if loop_count == 0:

                self.result.add_warning(
                    f'Object "{obj.name}" '
                    f'contains no loops.'
                )

            if polygon_count > 0:

                mesh.calc_loop_triangles()

                triangle_count = len(
                    mesh.loop_triangles
                )

                if triangle_count == 0:

                    self.result.add_warning(
                        f'Object "{obj.name}" '
                        f'contains polygons but '
                        f'no triangulated faces.'
                    )

    # =========================================================================
    # UV
    # =========================================================================

    def __validate_uv_layers(
        self,
    ):

        for obj in self.collection.objects:

            if obj.type != 'MESH':
                continue

            mesh = obj.data

            if mesh is None:
                continue

            if not mesh.uv_layers:

                self.result.add_warning(
                    f'Object "{obj.name}" '
                    f'has no UV layer.'
                )

                continue

            active_uv = (
                mesh.uv_layers.active
            )

            if active_uv is None:

                self.result.add_warning(
                    f'Object "{obj.name}" '
                    f'has UV layers but no '
                    f'active UV layer.'
                )

    # =========================================================================
    # VALIDATE COLLECTED EXPORT SCENE
    # =========================================================================

    def validate_scene(
        self,
        scene,
    ):
        """
        Validate collected export scene.

        This validation is performed after
        SceneCollector and before OBJWriter.
        """

        self.__validate_scene_totals(
            scene
        )

        self.__validate_export_groups(
            scene
        )

        self.__validate_export_objects(
            scene
        )

        return self.result

    # =========================================================================
    # SCENE TOTALS
    # =========================================================================

    def __validate_scene_totals(
        self,
        scene,
    ):

        if scene is None:

            self.result.add_error(
                "Collected export scene is not defined."
            )

            return

        total_vt = len(
            scene.vt_table
        )

        total_idx = len(
            scene.idx_table
        )

        total_tris = len(
            scene.tris_table
        )

        if total_vt != total_idx:

            self.result.add_error(
                "Collected scene geometry is invalid: "
                f"VT={total_vt}, "
                f"IDX={total_idx}."
            )

        if total_idx % 3 != 0:

            self.result.add_error(
                "Collected IDX count is not divisible "
                f"by 3: IDX={total_idx}."
            )

        expected_tris = (
            total_idx // 3
        )

        if total_tris != expected_tris:

            self.result.add_error(
                "Collected TRIS count does not match "
                f"IDX/3: "
                f"TRIS={total_tris}, "
                f"expected={expected_tris}."
            )

    # =========================================================================
    # EXPORT GROUPS
    # =========================================================================

    def __validate_export_groups(
        self,
        scene,
    ):

        if not scene.export_groups:

            self.result.add_error(
                "No export groups were created."
            )

            return

        total_vt = 0
        total_idx = 0
        total_tris = 0
        total_objects = 0

        for group in scene.export_groups:

            texture = (
                group.get("texture")
                or "<none>"
            )

            objects = (
                group.get(
                    "objects",
                    [],
                )
            )

            vt_table = (
                group.get(
                    "vt_table",
                    [],
                )
            )

            idx_table = (
                group.get(
                    "idx_table",
                    [],
                )
            )

            tris_table = (
                group.get(
                    "tris_table",
                    [],
                )
            )

            vt_count = len(
                vt_table
            )

            idx_count = len(
                idx_table
            )

            tris_count = len(
                tris_table
            )

            object_count = len(
                objects
            )

            #
            # Basic group counters.
            #

            if vt_count != idx_count:

                self.result.add_error(
                    "Export group has invalid "
                    "VT/IDX counts: "
                    f"texture={texture}, "
                    f"VT={vt_count}, "
                    f"IDX={idx_count}."
                )

            if idx_count % 3 != 0:

                self.result.add_error(
                    "Export group IDX count is "
                    "not divisible by 3: "
                    f"texture={texture}, "
                    f"IDX={idx_count}."
                )

            expected_tris = (
                idx_count // 3
            )

            if tris_count != expected_tris:

                self.result.add_error(
                    "Export group TRIS count does "
                    "not match IDX/3: "
                    f"texture={texture}, "
                    f"TRIS={tris_count}, "
                    f"expected={expected_tris}."
                )

            if object_count == 0:

                self.result.add_warning(
                    "Export group contains no objects: "
                    f"texture={texture}."
                )

            #
            # Validate IDX references.
            #

            self.__validate_group_indices(
                texture,
                vt_table,
                idx_table,
            )

            #
            # Validate TRIS ranges.
            #

            self.__validate_group_tris(
                texture,
                idx_table,
                tris_table,
            )

            #
            # Group totals.
            #

            total_vt += vt_count

            total_idx += idx_count

            total_tris += tris_count

            total_objects += object_count

        #
        # Compare group totals with
        # collected scene totals.
        #

        if total_vt != len(
            scene.vt_table
        ):

            self.result.add_error(
                "Export group VT total does not "
                "match collected scene VT total: "
                f"groups={total_vt}, "
                f"scene={len(scene.vt_table)}."
            )

        if total_idx != len(
            scene.idx_table
        ):

            self.result.add_error(
                "Export group IDX total does not "
                "match collected scene IDX total: "
                f"groups={total_idx}, "
                f"scene={len(scene.idx_table)}."
            )

        if total_tris != len(
            scene.tris_table
        ):

            self.result.add_error(
                "Export group TRIS total does not "
                "match collected scene TRIS total: "
                f"groups={total_tris}, "
                f"scene={len(scene.tris_table)}."
            )

        if total_objects != len(
            scene.meshes
        ):

            self.result.add_error(
                "Export group object total does not "
                "match collected mesh total: "
                f"groups={total_objects}, "
                f"meshes={len(scene.meshes)}."
            )

    # =========================================================================
    # GROUP IDX VALIDATION
    # =========================================================================

    def __validate_group_indices(
        self,
        texture,
        vt_table,
        idx_table,
    ):

        vt_count = len(
            vt_table
        )

        for index_position, index in enumerate(
            idx_table
        ):

            if not isinstance(
                index,
                int,
            ):

                self.result.add_error(
                    "Export group contains "
                    "non-integer IDX value: "
                    f"texture={texture}, "
                    f"position={index_position}, "
                    f"value={index}."
                )

                continue

            if index < 0:

                self.result.add_error(
                    "Export group contains "
                    "negative IDX value: "
                    f"texture={texture}, "
                    f"position={index_position}, "
                    f"IDX={index}."
                )

                continue

            if index >= vt_count:

                self.result.add_error(
                    "Export group IDX references "
                    "a VT record outside the group: "
                    f"texture={texture}, "
                    f"position={index_position}, "
                    f"IDX={index}, "
                    f"VT={vt_count}."
                )

    # =========================================================================
    # GROUP TRIS VALIDATION
    # =========================================================================

    def __validate_group_tris(
        self,
        texture,
        idx_table,
        tris_table,
    ):

        idx_count = len(
            idx_table
        )

        for tris_position, tris in enumerate(
            tris_table
        ):

            if not isinstance(
                tris,
                dict,
            ):

                self.result.add_error(
                    "Export group contains "
                    "invalid TRIS record: "
                    f"texture={texture}, "
                    f"position={tris_position}."
                )

                continue

            offset = tris.get(
                "offset"
            )

            count = tris.get(
                "count"
            )

            if not isinstance(
                offset,
                int,
            ):

                self.result.add_error(
                    "Export group TRIS has "
                    "non-integer offset: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"offset={offset}."
                )

                continue

            if not isinstance(
                count,
                int,
            ):

                self.result.add_error(
                    "Export group TRIS has "
                    "non-integer count: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"count={count}."
                )

                continue

            if offset < 0:

                self.result.add_error(
                    "Export group TRIS has "
                    "negative offset: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"offset={offset}."
                )

            if count <= 0:

                self.result.add_error(
                    "Export group TRIS has "
                    "non-positive count: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"count={count}."
                )

                continue

            if count % 3 != 0:

                self.result.add_error(
                    "Export group TRIS count is "
                    "not divisible by 3: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"count={count}."
                )

            end_offset = (
                offset + count
            )

            if end_offset > idx_count:

                self.result.add_error(
                    "Export group TRIS references "
                    "IDX records outside the group: "
                    f"texture={texture}, "
                    f"position={tris_position}, "
                    f"offset={offset}, "
                    f"count={count}, "
                    f"IDX={idx_count}."
                )

    # =========================================================================
    # EXPORT OBJECTS
    # =========================================================================

    def __validate_export_objects(
        self,
        scene,
    ):

        grouped_objects = []

        for group in scene.export_groups:

            for obj in group.get(
                "objects",
                [],
            ):

                grouped_objects.append(
                    obj
                )

        collected_objects = list(
            scene.meshes
        )

        if len(grouped_objects) != len(
            collected_objects
        ):

            self.result.add_error(
                "Some mesh objects were lost "
                "while creating export groups: "
                f"collected={len(collected_objects)}, "
                f"grouped={len(grouped_objects)}."
            )

            return

        collected_ids = {
            obj.as_pointer()
            for obj in collected_objects
        }

        grouped_ids = {
            obj.as_pointer()
            for obj in grouped_objects
        }

        missing = (
            collected_ids - grouped_ids
        )

        if missing:

            self.result.add_error(
                "One or more collected mesh "
                "objects are missing from "
                "export groups."
            )

        if len(grouped_ids) != len(
            grouped_objects
        ):

            self.result.add_error(
                "One or more mesh objects "
                "appear in multiple export groups."
            )
