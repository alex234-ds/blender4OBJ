# =============================================================================
# Project : export_Blender5_XP12
# File    : core/obj_validator.py
#
# Company : Alex234 Design Studio
#
# Blender : 5.1+
#
# Purpose (EN):
#     Validation of generated X-Plane OBJ8 files.
#
# Назначение (RU):
#     Проверка фактически созданных OBJ8-файлов после экспорта.
# =============================================================================

from pathlib import Path

from .validation_result import ALX_ValidationResult


class ALX_OBJValidator:
    """
    Validate generated X-Plane OBJ8 files.
    """

    def __init__(self):

        self.result = (
            ALX_ValidationResult()
        )

    # =========================================================================
    # VALIDATE
    # =========================================================================

    def validate(
        self,
        output_files,
        scene,
    ):

        self.result = (
            ALX_ValidationResult()
        )

        groups = (
            scene.export_groups
        )

        if len(output_files) != len(
            groups
        ):

            self.result.add_error(
                "Generated OBJ file count does not "
                "match export group count: "
                f"files={len(output_files)}, "
                f"groups={len(groups)}."
            )

            return self.result

        for filepath, group in zip(
            output_files,
            groups,
        ):

            self.__validate_file(
                filepath,
                group,
            )

        return self.result

    # =========================================================================
    # FILE
    # =========================================================================

    def __validate_file(
        self,
        filepath,
        group,
    ):

        path = Path(
            filepath
        )

        if not path.exists():

            self.result.add_error(
                "OBJ file was not created: "
                f"{path.name}."
            )

            return

        if not path.is_file():

            self.result.add_error(
                "OBJ output path is not a file: "
                f"{path.name}."
            )

            return

        try:

            with open(
                path,
                "r",
                encoding="utf-8",
            ) as file:

                lines = file.readlines()

        except Exception as exc:

            self.result.add_error(
                "Unable to read generated OBJ file: "
                f"{path.name}: {exc}"
            )

            return

        self.__validate_header(
            path,
            lines,
        )

        actual = (
            self.__parse_obj(
                path,
                lines,
            )
        )

        if actual is None:

            return

        self.__validate_texture(
            path,
            group,
            actual,
        )

        self.__validate_point_counts(
            path,
            group,
            actual,
        )

        self.__validate_geometry_counts(
            path,
            group,
            actual,
        )

        if not self.result.errors:

            self.result.add_info(
                "OBJ file validated successfully: "
                f"{path.name}."
            )

    # =========================================================================
    # HEADER
    # =========================================================================

    def __validate_header(
        self,
        path,
        lines,
    ):

        content = [
            line.strip()
            for line in lines
            if line.strip()
        ]

        if len(content) < 2:

            self.result.add_error(
                "OBJ file is too short: "
                f"{path.name}."
            )

            return

        if content[0] != "A":

            self.result.add_error(
                "Invalid OBJ header in "
                f"{path.name}: expected 'A'."
            )

        if content[1] != "800":

            self.result.add_error(
                "Invalid OBJ version in "
                f"{path.name}: expected '800'."
            )

        if "OBJ" not in content:

            self.result.add_error(
                "OBJ file does not contain "
                f"'OBJ' declaration: {path.name}."
            )

    # =========================================================================
    # PARSE OBJ
    # =========================================================================

    def __parse_obj(
        self,
        path,
        lines,
    ):

        actual = {

            "texture": None,

            "point_counts": None,

            "vt": 0,

            "idx": 0,

            "tris": 0,

        }

        point_counts_found = False

        for raw_line in lines:

            line = raw_line.strip()

            if not line:

                continue

            #
            # TEXTURE
            #

            if line.startswith(
                "TEXTURE"
            ):

                parts = line.split(
                    maxsplit=1
                )

                if len(parts) == 2:

                    texture = (
                        parts[1].strip()
                    )

                    if texture:

                        actual["texture"] = (
                            texture
                        )

                else:

                    actual["texture"] = None

                continue

            #
            # POINT_COUNTS
            #

            if line.startswith(
                "POINT_COUNTS"
            ):

                parts = line.split()

                if len(parts) != 5:

                    self.result.add_error(
                        "Invalid POINT_COUNTS line "
                        f"in {path.name}: "
                        f"{line}"
                    )

                    continue

                try:

                    actual[
                        "point_counts"
                    ] = [

                        int(parts[1]),
                        int(parts[2]),
                        int(parts[3]),
                        int(parts[4]),

                    ]

                    point_counts_found = True

                except ValueError:

                    self.result.add_error(
                        "Invalid numeric values in "
                        f"POINT_COUNTS in {path.name}: "
                        f"{line}"
                    )

                continue

            #
            # VT
            #

            if line.startswith(
                "VT "
            ):

                actual["vt"] += 1

                continue

            #
            # IDX
            #

            if line.startswith(
                "IDX "
            ):

                parts = line.split()

                if len(parts) > 1:

                    try:

                        actual["idx"] += (
                            len(parts) - 1
                        )

                    except Exception:

                        self.result.add_error(
                            "Invalid IDX line "
                            f"in {path.name}: "
                            f"{line}"
                        )

                continue

            #
            # TRIS
            #

            if line.startswith(
                "TRIS "
            ):

                actual["tris"] += 1

                continue

        if not point_counts_found:

            self.result.add_error(
                "OBJ file does not contain "
                f"POINT_COUNTS: {path.name}."
            )

            return None

        return actual

    # =========================================================================
    # TEXTURE
    # =========================================================================

    def __validate_texture(
        self,
        path,
        group,
        actual,
    ):

        expected_texture = (
            group.get("texture")
        )

        actual_texture = (
            actual.get("texture")
        )

        expected_texture = (
            expected_texture
            if expected_texture
            else None
        )

        actual_texture = (
            actual_texture
            if actual_texture
            else None
        )

        if expected_texture != (
            actual_texture
        ):

            expected_text = (
                expected_texture
                or "<none>"
            )

            actual_text = (
                actual_texture
                or "<none>"
            )

            self.result.add_error(
                "OBJ texture does not match "
                f"export group in {path.name}: "
                f"expected={expected_text}, "
                f"actual={actual_text}."
            )

    # =========================================================================
    # POINT COUNTS
    # =========================================================================

    def __validate_point_counts(
        self,
        path,
        group,
        actual,
    ):

        point_counts = (
            actual.get(
                "point_counts"
            )
        )

        if point_counts is None:

            return

        expected_vt = len(
            group.get(
                "vt_table",
                [],
            )
        )

        expected_idx = len(
            group.get(
                "idx_table",
                [],
            )
        )

        expected_tris = len(
            group.get(
                "tris_table",
                [],
            )
        )

        expected_point_counts = [

            expected_vt,
            0,
            1,
            expected_vt,

        ]

        if point_counts != (
            expected_point_counts
        ):

            self.result.add_error(
                "POINT_COUNTS does not match "
                f"export group in {path.name}: "
                f"expected={expected_point_counts}, "
                f"actual={point_counts}."
            )

    # =========================================================================
    # GEOMETRY COUNTS
    # =========================================================================

    def __validate_geometry_counts(
        self,
        path,
        group,
        actual,
    ):

        expected_vt = len(
            group.get(
                "vt_table",
                [],
            )
        )

        expected_idx = len(
            group.get(
                "idx_table",
                [],
            )
        )

        expected_tris = len(
            group.get(
                "tris_table",
                [],
            )
        )

        actual_vt = (
            actual["vt"]
        )

        actual_idx = (
            actual["idx"]
        )

        actual_tris = (
            actual["tris"]
        )

        #
        # VT
        #

        if actual_vt != (
            expected_vt
        ):

            self.result.add_error(
                "OBJ VT count does not match "
                f"export group in {path.name}: "
                f"expected={expected_vt}, "
                f"actual={actual_vt}."
            )

        #
        # IDX
        #

        if actual_idx != (
            expected_idx
        ):

            self.result.add_error(
                "OBJ IDX count does not match "
                f"export group in {path.name}: "
                f"expected={expected_idx}, "
                f"actual={actual_idx}."
            )

        #
        # TRIS
        #

        if actual_tris != (
            expected_tris
        ):

            self.result.add_error(
                "OBJ TRIS count does not match "
                f"export group in {path.name}: "
                f"expected={expected_tris}, "
                f"actual={actual_tris}."
            )

        #
        # VT / IDX
        #

        if actual_vt != (
            actual_idx
        ):

            self.result.add_error(
                "OBJ VT/IDX counts are inconsistent "
                f"in {path.name}: "
                f"VT={actual_vt}, "
                f"IDX={actual_idx}."
            )

        #
        # IDX / 3
        #

        if actual_idx % 3 != 0:

            self.result.add_error(
                "OBJ IDX count is not divisible "
                f"by 3 in {path.name}: "
                f"IDX={actual_idx}."
            )

        #
        # TRIS / IDX
        #

        expected_actual_tris = (
            actual_idx // 3
        )

        if actual_tris != (
            expected_actual_tris
        ):

            self.result.add_error(
                "OBJ TRIS count does not match "
                f"IDX/3 in {path.name}: "
                f"TRIS={actual_tris}, "
                f"expected={expected_actual_tris}."
            )
